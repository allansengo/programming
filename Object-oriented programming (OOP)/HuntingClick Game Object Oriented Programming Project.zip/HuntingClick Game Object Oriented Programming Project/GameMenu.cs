﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GoTogether_HuntingGame
{
    public partial class GameMenu : Form
    {

        int Score = 0;
        int seconds = 0;
       

        public GameMenu(object text)
        {
            InitializeComponent();
           
        }

        private void GameMenu_Load(object sender, EventArgs e)
        {
            // Display Text Input on Form 1 To form 2
            label1.Text = Form1.SetValueForText1;

            {
                // Increase From size when score is =10 , 20, 30 , 40, 50 ( This is not working, becase i guess form.size is ReadOnly)
                if  (Score == 10)
                    GameMenu.ActiveForm.Width = GameMenu.ActiveForm.Size.Width + 10;
                    GameMenu.ActiveForm.Height = GameMenu.ActiveForm.Size.Height + 10;
            }

            {
                if (Score == 20)
                    GameMenu.ActiveForm.Width = GameMenu.ActiveForm.Size.Width + 10;
                GameMenu.ActiveForm.Height = GameMenu.ActiveForm.Size.Height + 10;
            }

            {
                if (Score == 30)
                    GameMenu.ActiveForm.Width = GameMenu.ActiveForm.Size.Width + 10;
                GameMenu.ActiveForm.Height = GameMenu.ActiveForm.Size.Height + 10;
            }

            {
                if (Score == 40)
                    GameMenu.ActiveForm.Width = GameMenu.ActiveForm.Size.Width + 10;
                GameMenu.ActiveForm.Height = GameMenu.ActiveForm.Size.Height + 10;
            }

            {
                if (Score == 50)
                    GameMenu.ActiveForm.Width = GameMenu.ActiveForm.Size.Width + 10;
                GameMenu.ActiveForm.Height = GameMenu.ActiveForm.Size.Height + 10;
            }
        }

        //Start Game by Initiating GameTimer, Show PcitureBox and Dissable Difificluty buttons when clicked
        private void button1_Click(object sender, EventArgs e)
        {

            GameTimer.Start();
            button1.Enabled = false;
            pictureBox1.Visible = true;
            EasyDiffTimeSpeedBtn.Enabled = false;
            MediumDiffTimeSpeedBtn.Enabled = false;
            HardDiffTimeSpeedBtn.Enabled = false;

        }

        // Changes GameTimer Interval to set diffirent difficulties in correaltion to speed of Timer
        // Also assigns diffirent time staring points  ( second = number )
        private void EasyDiffTimeSpeedBtn_CheckedChanged(object sender, EventArgs e)
        {   
            GameTimer.Interval = 1000;
            seconds = 25;

        }

        private void MediumDiffTimeSpeedBtn_CheckedChanged(object sender, EventArgs e)
        {
            GameTimer.Interval = 750;
            seconds = 20;

        }


        private void HardDiffTimeSpeedBtn_CheckedChanged(object sender, EventArgs e)
        {
            GameTimer.Interval = 500;
            seconds = 15;

        }

        
        
        private void pictureBox1_Click(object sender, EventArgs e)
        {
            //Each Click will add +1 to score
            Score += 1;
            Scorelabel.Text = Score.ToString();

            //For every click will, the picture will repostion at random
            Random r = new Random();
            int x = r.Next(200,450);
            int y = r.Next(0,450);
            pictureBox1.Location = new Point(x,y);

            //Changes picture when score is = 10 , 20, 30 , 40, 50
            {
                if (Score == 10)
                    pictureBox1.Image = Properties.Resources.Grin_Face;
            }

            {
                if (Score == 20)
                    pictureBox1.Image = Properties.Resources.Smile_face;
            }

            {
                if (Score == 30)
                    pictureBox1.Image = Properties.Resources.Grin_Face;
            }

            {
                if (Score == 40)
                    pictureBox1.Image = Properties.Resources.Surprised_Face;
            }

            {
                if (Score == 50)
                    pictureBox1.Image = Properties.Resources.Surprised_Face;
            }

            //Bonus Time Award for if User reaches = 10, 20, 30 , 40 
            {
                if (Score == 10)
                    seconds += 10;
                
            }
             
            {
                if (Score == 20)
                    seconds += 8;
            }

            {
                if (Score == 30)
                    seconds += 6;
            }

            {
                if (Score == 40)
                    seconds += 4;
            }

            // Game reaches constant mode, Where if user score = 50, User time increases +2 seconds but time interval decreases for difficulty
            {
                if (Score == 50)
                    seconds += 2;
               
                {
                    if (Score > 50 )
                        seconds += 2;
                }

                {
                    if (Score > 50)
                        GameTimer.Interval = 250;
                }

               

            }
        }



        private void GameTimer_Tick(object sender, EventArgs e)

        {   //Label Time of the staring at difficulty level was selected ( E.g Easy: seconds=25;)
            TimeLabel.Text = seconds--.ToString();
            
            //Stop timer if time is less then 0, for Game procedure
            if (seconds < 0)
            {
                GameTimer.Stop();
            }

            //GameOver Menu for if time reaches < 0 
            if (seconds < 0)
            {
                MessageBox.Show("Game Over" + Environment.NewLine + "Score:" + Score, "GameOver Menu");
                
                //Restart application to reinitiatte Game 
                Application.Restart();
            }

            //Resets All fields to default 
            if (seconds < 0)
            {    
                button1.Enabled = true;
            }

            if (seconds < 0)
            {
               pictureBox1.Visible = false;
            }

            if (seconds < 0)
            {
                EasyDiffTimeSpeedBtn.Enabled = true;
            }

            if (seconds < 0)
            {
                MediumDiffTimeSpeedBtn.Enabled = true;
            }

            if (seconds < 0)
            {
                HardDiffTimeSpeedBtn.Enabled = true;
            }

           

        }

        //Close Application
        private void ExitGameMenuBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
