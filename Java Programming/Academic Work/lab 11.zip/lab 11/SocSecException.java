public class SocSecException {
    public class SocSecException extends Exception {
        
        public SocSecException() // default constructor
        {
                super();
        }
        
        public SocSecException(String message) // parameterized constructor
        {
                super("Inavalid social security number, " + message);
        }

}