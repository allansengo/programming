﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace ITPoland_Project_4
{
    public partial class Form2 : Form
    {
        public int numberOfContacts;
        int currentContact = 1;
        int currentContactFromList = 0;
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            
        }

        private void Form2_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void backToMenuButton_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            this.Hide();
            form1.ShowDialog();
        }

        private void nextRecordButton_Click(object sender, EventArgs e)
        {
            currentContact++;
            currentContactFromList++;
            currentContactLabel.Text = currentContact + "";
            if (currentContact < numberOfContacts && currentContact > 1)
            {
                nextRecordButton.Enabled = true;
                previouseRecordButton.Enabled = true;
            }
            else if (currentContact == numberOfContacts)
            {
                nextRecordButton.Enabled = false;
                previouseRecordButton.Enabled = true;
            }

            nameLabel.Text = Contacts.contacts[currentContactFromList].name;
            middleNameLabel.Text = Contacts.contacts[currentContactFromList].middleName;
            lastNameLabel.Text = Contacts.contacts[currentContactFromList].lastName;
            phoneNumberLabel.Text = Contacts.contacts[currentContactFromList].phoneNumber + "";
            addressLabel.Text = Contacts.contacts[currentContactFromList].address;
            genderLabel.Text = Contacts.contacts[currentContactFromList].gender;
            Bitmap image = new Bitmap(Contacts.contacts[currentContactFromList].pathImage);
            pictureBox1.Image = image;
        }

        private void previouseRecordButton_Click(object sender, EventArgs e)
        {
            currentContact--;
            currentContactFromList--;
            currentContactLabel.Text = currentContact + "";
            if (currentContact < numberOfContacts && currentContact > 1)
            {
                nextRecordButton.Enabled = true;
                previouseRecordButton.Enabled = true;
            }
            else if (currentContact == 1)
            {
                previouseRecordButton.Enabled = false;
                nextRecordButton.Enabled = true;
            }

            nameLabel.Text = Contacts.contacts[currentContactFromList].name;
            middleNameLabel.Text = Contacts.contacts[currentContactFromList].middleName;
            lastNameLabel.Text = Contacts.contacts[currentContactFromList].lastName;
            phoneNumberLabel.Text = Contacts.contacts[currentContactFromList].phoneNumber + "";
            addressLabel.Text = Contacts.contacts[currentContactFromList].address;
            genderLabel.Text = Contacts.contacts[currentContactFromList].gender;
            Bitmap image = new Bitmap(Contacts.contacts[currentContactFromList].pathImage);
            pictureBox1.Image = image;
        }
    }
}
