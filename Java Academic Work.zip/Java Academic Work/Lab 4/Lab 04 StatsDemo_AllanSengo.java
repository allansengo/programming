import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Scanner;
// TASK #3 Add the file I/O import statement here
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.*;

/**
   This class reads numbers from a file, calculates the
   mean and standard deviation, and writes the results
   to a file.
*/

public class StatsDemo
{
   
public static void main(String[] args) throws IOException
   {
      double sum = 0;      // The sum of the numbers
      int count = 0;       // The number of numbers added
      double mean = 0;     // The average of the numbers
      double stdDev = 0;   // The standard deviation
      String line;         // To hold a line from the file
      double difference;   // The value and mean difference
      ArrayList<Double> values = new ArrayList<>();

      Scanner keyboard = new Scanner (System.in);
      String filename;  

      System.out.println("This program calculates " +
                         "statistics on a file " +
                         "containing a series of numbers");
      System.out.print("Enter the file name:  ");
      filename = keyboard.nextLine();
      keyboard.close();
      
      FileReader File = new FileReader(filename);
      BufferedReader readFile = new BufferedReader(File);
      line = readFile.readLine();
      while(true){
    	  line = readFile.readLine();
    	  if(line == null)
    		  break;
    	  else{
    		  values.add(Double.parseDouble(line));
    		 sum += Double.valueOf(line);
        	 count += 1; 
    	  }	
      }
      readFile.close();
      System.out.println(count);
      mean = sum / count;
      
      FileReader File_read = new FileReader(filename);
      BufferedReader read_File = new BufferedReader(File_read);
      sum = 0; count = 0;
      line = read_File.readLine();
      while(true){
    	  line = read_File.readLine();
    	  if(line == null)
    		  break;
    	  else{
    		  difference = (Double.valueOf(line) - mean);
    		  sum += Math.pow(difference, 2);
    		  count += 1;  
    	  }
      }
      read_File.close();
      stdDev = Math.sqrt(sum / count - 1);
      
      FileWriter write = new FileWriter("Result.txt");
      PrintWriter output = new PrintWriter(write);
      output.printf("Mean of %s = %.3f.\n\n", values.toString(), mean);
      output.printf("Standard Deviation of %s  = %.3f.",values.toString(), stdDev);
      output.close();
   }

      
      // ADD LINES FOR TASK #4 HERE

      // Create a FileReader object passing it the filename
      Reader FileReader = new File(Filename);

      // Create a BufferedReader object passing FileReader
      // object
      BufferReader bufferedReader= new BufferedReader(FileReader);

      // Perform a priming read to read the first line of
      // the file
      // Loop until you are at the end of the file
      while (inputFile.hasNext());
      line = inputFile.nextline();

      // Convert the line to a double value and add the
      // value to sum
      double number = Double.parseDouble(Line);
      sum +=number;

      // Increment the counter
      count++;
      // Read a new line from the file

      // Close the input file
      inputFile.Close();

      // Store the calculated mean
      System.out.print("Sum of Numbers: \n"+ sum+"\nCounter: \n"+count+"\nCalculated mean: \nCalculated mean: \n"+(mean=sum/count));

      // ADD LINES FOR TASK #5 HERE
      // Reconnect FileReader object passing it the
      // filename
      FileReader file2 = new FileReader(filename);

      // Reconnect BufferedReader object passing
      // FileReader object
      BufferedReader input2 = new BufferedReader(file2); 
      
      // Reinitialize the sum of the numbers
      sum = 0;    

      // Reinitialize the number of numbers added
      count = 0;


      // Perform a priming read to read the first line of
      // the file
      line = input2.readLine();

      // Loop until you are at the end of the file
      while (line != null) 

      {
         difference = Double.parseDouble(line) - mean;       // Convert the line into a double value and subtract the mean.
         sum += Math.pow(difference, 2);                     // Add the square of the difference to the sum.
         count++;                                            // Increment the counter.
         line = input2.readLine();                           // Read a new line from the file.
     }
      
      // Close the input file
      input2.close();    

      // Store the calculated standard deviation
      stdDev = Math.sqrt((sum / count));   

      // ADD LINES FOR TASK #3 HERE
      // Create a FileWriter object using "Results.txt"
      FileWriter fw=new FileWriter("Results.txt");

      // Create a PrintWriter object passing the
      PrintWriter output = new PrintWriter(fWriter); 

      // FileWriter object
      pw.printf("mean = %5.3f\n", mean);
      
      // Print the results to the output file.
      output.println("The mean is " +                                     
      threeDecimals.format(mean) + " and the standard " +
      "deviation is " + threeDecimals.format(stdDev) + ".");

      // Close the output file
      output.close(); 
   }
}