﻿using System;
using System.Threading;

namespace ex1
{
    class Program
    {
	static void Fun()
	{
	    for (int i = 0; i < 16; ++i) Console.WriteLine($"Worker thread: {i}");
	}

        static void Main(string[] args)
        {
	    Thread t = new Thread(Fun);
	    t.Start();
	    for (int i = 0; i < 16; ++i) Console.WriteLine($"Main thread: {i}");
	    t.Join();
        }
    }
}
