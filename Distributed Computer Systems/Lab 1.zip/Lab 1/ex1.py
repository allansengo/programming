from threading import Thread


def fun():
    print("Hello from the worker thread!\n", end="")


def main():
    t = Thread(target=fun)
    t.start()
    print("Greetings from the main thread!\n", end="")
    t.join()


if __name__ == "__main__":
    main()

