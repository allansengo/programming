
package postalcode;

public class OotumilaPostalCode  extends PostalCode
{
    //Constructors ****************************************************

    /**
     * Constructs a Canadian postal code object.
     *
     * @param code The code to be analysed.
     */
    public OotumilaPostalCode(String code) throws PostalCodeException
    {
        super(code);
    }

    //Instance methods ************************************************

    /**
     * Returns the country of origin of the code.
     *
     * @return A String containing the country of origin of the code.
     */
    public String getCountry()
    {
        return "Ootumila";
    }

    /**
     * This method will verify the validity of the postal code.
     *
     * @throws PostalCodeException If the code is found to be invalid.
     */
    protected void validate() throws PostalCodeException {
        String postCode = getCode();
        // Check code format, throw an exception if it is invalid.
        if ((postCode.length() == 0)
                || (!Character.isLetter(postCode.charAt(0)))
                || (!Character.isLetter(postCode.charAt(1)))

                || (!Character.isWhitespace(postCode.charAt(2)))

                || (!Character.isDigit(postCode.charAt(3)))
                || (!Character.isDigit(postCode.charAt(4)))

                || (!Character.isUpperCase(postCode.charAt(0)))
                || (!Character.isUpperCase(postCode.charAt(1)))

                || (postCode.length() > 6)) {
            throwException("Sequence of characters not like AA 99");
        } else {
            setDestination(computeDestination());
        }
    }
        private String computeDestination () throws PostalCodeException
        {
           setDestination("in Ootumila");
            return "";
        }

        /**
         * This method will return the destination of the postal code.
         *
         * @throws PostalCodeException If the code has an invalid letter
         *                             to indicate a destination.
         */


    }