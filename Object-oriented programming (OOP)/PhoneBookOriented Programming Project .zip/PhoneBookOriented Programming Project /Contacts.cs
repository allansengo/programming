﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ITPoland_Project_4
{
    static class Contacts
    {
        public static List<Contact> contacts = new List<Contact>();
    }
}
