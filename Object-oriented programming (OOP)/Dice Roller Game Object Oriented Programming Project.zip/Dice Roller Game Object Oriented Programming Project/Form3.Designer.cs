﻿
namespace ITPoland_Project_3
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.playerPanel1 = new System.Windows.Forms.Panel();
            this.bank1 = new System.Windows.Forms.Label();
            this.score1 = new System.Windows.Forms.Label();
            this.bankLabel1 = new System.Windows.Forms.Label();
            this.scoreLabel1 = new System.Windows.Forms.Label();
            this.nameLabel1 = new System.Windows.Forms.Label();
            this.playerPanel2 = new System.Windows.Forms.Panel();
            this.bank2 = new System.Windows.Forms.Label();
            this.score2 = new System.Windows.Forms.Label();
            this.bankLabel2 = new System.Windows.Forms.Label();
            this.scoreLabel2 = new System.Windows.Forms.Label();
            this.nameLabel2 = new System.Windows.Forms.Label();
            this.playerPanel3 = new System.Windows.Forms.Panel();
            this.bank3 = new System.Windows.Forms.Label();
            this.score3 = new System.Windows.Forms.Label();
            this.bankLabel3 = new System.Windows.Forms.Label();
            this.scoreLabel3 = new System.Windows.Forms.Label();
            this.nameLabel3 = new System.Windows.Forms.Label();
            this.playerPanel4 = new System.Windows.Forms.Panel();
            this.bank4 = new System.Windows.Forms.Label();
            this.score4 = new System.Windows.Forms.Label();
            this.bankLabel4 = new System.Windows.Forms.Label();
            this.scoreLabel4 = new System.Windows.Forms.Label();
            this.nameLabel4 = new System.Windows.Forms.Label();
            this.rollButton = new System.Windows.Forms.Button();
            this.saveButton = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.turnLabel = new System.Windows.Forms.Label();
            this.playerPanel1.SuspendLayout();
            this.playerPanel2.SuspendLayout();
            this.playerPanel3.SuspendLayout();
            this.playerPanel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // playerPanel1
            // 
            this.playerPanel1.Controls.Add(this.bank1);
            this.playerPanel1.Controls.Add(this.score1);
            this.playerPanel1.Controls.Add(this.bankLabel1);
            this.playerPanel1.Controls.Add(this.scoreLabel1);
            this.playerPanel1.Controls.Add(this.nameLabel1);
            this.playerPanel1.Location = new System.Drawing.Point(0, 0);
            this.playerPanel1.Name = "playerPanel1";
            this.playerPanel1.Size = new System.Drawing.Size(200, 137);
            this.playerPanel1.TabIndex = 0;
            this.playerPanel1.TabStop = true;
            // 
            // bank1
            // 
            this.bank1.AutoSize = true;
            this.bank1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.bank1.Location = new System.Drawing.Point(100, 94);
            this.bank1.Name = "bank1";
            this.bank1.Size = new System.Drawing.Size(21, 24);
            this.bank1.TabIndex = 4;
            this.bank1.Text = "0";
            // 
            // score1
            // 
            this.score1.AutoSize = true;
            this.score1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.score1.Location = new System.Drawing.Point(100, 53);
            this.score1.Name = "score1";
            this.score1.Size = new System.Drawing.Size(21, 24);
            this.score1.TabIndex = 3;
            this.score1.Text = "0";
            // 
            // bankLabel1
            // 
            this.bankLabel1.AutoSize = true;
            this.bankLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.bankLabel1.Location = new System.Drawing.Point(12, 94);
            this.bankLabel1.Name = "bankLabel1";
            this.bankLabel1.Size = new System.Drawing.Size(62, 24);
            this.bankLabel1.TabIndex = 2;
            this.bankLabel1.Text = "Bank:";
            // 
            // scoreLabel1
            // 
            this.scoreLabel1.AutoSize = true;
            this.scoreLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.scoreLabel1.Location = new System.Drawing.Point(12, 53);
            this.scoreLabel1.Name = "scoreLabel1";
            this.scoreLabel1.Size = new System.Drawing.Size(71, 24);
            this.scoreLabel1.TabIndex = 1;
            this.scoreLabel1.Text = "Score:";
            // 
            // nameLabel1
            // 
            this.nameLabel1.AutoSize = true;
            this.nameLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.nameLabel1.Location = new System.Drawing.Point(76, 9);
            this.nameLabel1.Name = "nameLabel1";
            this.nameLabel1.Size = new System.Drawing.Size(0, 16);
            this.nameLabel1.TabIndex = 0;
            this.nameLabel1.Click += new System.EventHandler(this.playerNameLabel1_Click);
            // 
            // playerPanel2
            // 
            this.playerPanel2.Controls.Add(this.bank2);
            this.playerPanel2.Controls.Add(this.score2);
            this.playerPanel2.Controls.Add(this.bankLabel2);
            this.playerPanel2.Controls.Add(this.scoreLabel2);
            this.playerPanel2.Controls.Add(this.nameLabel2);
            this.playerPanel2.Location = new System.Drawing.Point(0, 273);
            this.playerPanel2.Name = "playerPanel2";
            this.playerPanel2.Size = new System.Drawing.Size(200, 137);
            this.playerPanel2.TabIndex = 1;
            this.playerPanel2.Paint += new System.Windows.Forms.PaintEventHandler(this.playerPanel2_Paint);
            // 
            // bank2
            // 
            this.bank2.AutoSize = true;
            this.bank2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.bank2.Location = new System.Drawing.Point(100, 94);
            this.bank2.Name = "bank2";
            this.bank2.Size = new System.Drawing.Size(21, 24);
            this.bank2.TabIndex = 5;
            this.bank2.Text = "0";
            // 
            // score2
            // 
            this.score2.AutoSize = true;
            this.score2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.score2.Location = new System.Drawing.Point(100, 58);
            this.score2.Name = "score2";
            this.score2.Size = new System.Drawing.Size(21, 24);
            this.score2.TabIndex = 4;
            this.score2.Text = "0";
            // 
            // bankLabel2
            // 
            this.bankLabel2.AutoSize = true;
            this.bankLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.bankLabel2.Location = new System.Drawing.Point(12, 94);
            this.bankLabel2.Name = "bankLabel2";
            this.bankLabel2.Size = new System.Drawing.Size(62, 24);
            this.bankLabel2.TabIndex = 3;
            this.bankLabel2.Text = "Bank:";
            // 
            // scoreLabel2
            // 
            this.scoreLabel2.AutoSize = true;
            this.scoreLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.scoreLabel2.Location = new System.Drawing.Point(12, 58);
            this.scoreLabel2.Name = "scoreLabel2";
            this.scoreLabel2.Size = new System.Drawing.Size(71, 24);
            this.scoreLabel2.TabIndex = 2;
            this.scoreLabel2.Text = "Score:";
            // 
            // nameLabel2
            // 
            this.nameLabel2.AutoSize = true;
            this.nameLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.nameLabel2.Location = new System.Drawing.Point(76, 10);
            this.nameLabel2.Name = "nameLabel2";
            this.nameLabel2.Size = new System.Drawing.Size(0, 16);
            this.nameLabel2.TabIndex = 1;
            // 
            // playerPanel3
            // 
            this.playerPanel3.Controls.Add(this.bank3);
            this.playerPanel3.Controls.Add(this.score3);
            this.playerPanel3.Controls.Add(this.bankLabel3);
            this.playerPanel3.Controls.Add(this.scoreLabel3);
            this.playerPanel3.Controls.Add(this.nameLabel3);
            this.playerPanel3.Location = new System.Drawing.Point(373, 0);
            this.playerPanel3.Name = "playerPanel3";
            this.playerPanel3.Size = new System.Drawing.Size(200, 137);
            this.playerPanel3.TabIndex = 2;
            // 
            // bank3
            // 
            this.bank3.AutoSize = true;
            this.bank3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.bank3.Location = new System.Drawing.Point(102, 94);
            this.bank3.Name = "bank3";
            this.bank3.Size = new System.Drawing.Size(21, 24);
            this.bank3.TabIndex = 5;
            this.bank3.Text = "0";
            // 
            // score3
            // 
            this.score3.AutoSize = true;
            this.score3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.score3.Location = new System.Drawing.Point(102, 54);
            this.score3.Name = "score3";
            this.score3.Size = new System.Drawing.Size(21, 24);
            this.score3.TabIndex = 4;
            this.score3.Text = "0";
            // 
            // bankLabel3
            // 
            this.bankLabel3.AutoSize = true;
            this.bankLabel3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.bankLabel3.Location = new System.Drawing.Point(15, 94);
            this.bankLabel3.Name = "bankLabel3";
            this.bankLabel3.Size = new System.Drawing.Size(62, 24);
            this.bankLabel3.TabIndex = 3;
            this.bankLabel3.Text = "Bank:";
            // 
            // scoreLabel3
            // 
            this.scoreLabel3.AutoSize = true;
            this.scoreLabel3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.scoreLabel3.Location = new System.Drawing.Point(15, 53);
            this.scoreLabel3.Name = "scoreLabel3";
            this.scoreLabel3.Size = new System.Drawing.Size(71, 24);
            this.scoreLabel3.TabIndex = 2;
            this.scoreLabel3.Text = "Score:";
            // 
            // nameLabel3
            // 
            this.nameLabel3.AutoSize = true;
            this.nameLabel3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.nameLabel3.Location = new System.Drawing.Point(77, 9);
            this.nameLabel3.Name = "nameLabel3";
            this.nameLabel3.Size = new System.Drawing.Size(0, 16);
            this.nameLabel3.TabIndex = 1;
            // 
            // playerPanel4
            // 
            this.playerPanel4.Controls.Add(this.bank4);
            this.playerPanel4.Controls.Add(this.score4);
            this.playerPanel4.Controls.Add(this.bankLabel4);
            this.playerPanel4.Controls.Add(this.scoreLabel4);
            this.playerPanel4.Controls.Add(this.nameLabel4);
            this.playerPanel4.Location = new System.Drawing.Point(373, 273);
            this.playerPanel4.Name = "playerPanel4";
            this.playerPanel4.Size = new System.Drawing.Size(200, 137);
            this.playerPanel4.TabIndex = 3;
            // 
            // bank4
            // 
            this.bank4.AutoSize = true;
            this.bank4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.bank4.Location = new System.Drawing.Point(102, 94);
            this.bank4.Name = "bank4";
            this.bank4.Size = new System.Drawing.Size(21, 24);
            this.bank4.TabIndex = 5;
            this.bank4.Text = "0";
            // 
            // score4
            // 
            this.score4.AutoSize = true;
            this.score4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.score4.Location = new System.Drawing.Point(102, 58);
            this.score4.Name = "score4";
            this.score4.Size = new System.Drawing.Size(21, 24);
            this.score4.TabIndex = 4;
            this.score4.Text = "0";
            // 
            // bankLabel4
            // 
            this.bankLabel4.AutoSize = true;
            this.bankLabel4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.bankLabel4.Location = new System.Drawing.Point(15, 94);
            this.bankLabel4.Name = "bankLabel4";
            this.bankLabel4.Size = new System.Drawing.Size(62, 24);
            this.bankLabel4.TabIndex = 3;
            this.bankLabel4.Text = "Bank:";
            // 
            // scoreLabel4
            // 
            this.scoreLabel4.AutoSize = true;
            this.scoreLabel4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.scoreLabel4.Location = new System.Drawing.Point(15, 58);
            this.scoreLabel4.Name = "scoreLabel4";
            this.scoreLabel4.Size = new System.Drawing.Size(71, 24);
            this.scoreLabel4.TabIndex = 2;
            this.scoreLabel4.Text = "Score:";
            // 
            // nameLabel4
            // 
            this.nameLabel4.AutoSize = true;
            this.nameLabel4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.nameLabel4.Location = new System.Drawing.Point(77, 12);
            this.nameLabel4.Name = "nameLabel4";
            this.nameLabel4.Size = new System.Drawing.Size(0, 16);
            this.nameLabel4.TabIndex = 1;
            // 
            // rollButton
            // 
            this.rollButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.rollButton.Location = new System.Drawing.Point(238, 26);
            this.rollButton.Name = "rollButton";
            this.rollButton.Size = new System.Drawing.Size(84, 40);
            this.rollButton.TabIndex = 4;
            this.rollButton.Text = "Roll";
            this.rollButton.UseVisualStyleBackColor = true;
            this.rollButton.Click += new System.EventHandler(this.rollButton_Click);
            // 
            // saveButton
            // 
            this.saveButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.saveButton.Location = new System.Drawing.Point(238, 78);
            this.saveButton.Name = "saveButton";
            this.saveButton.Size = new System.Drawing.Size(84, 40);
            this.saveButton.TabIndex = 5;
            this.saveButton.Text = "Save";
            this.saveButton.UseVisualStyleBackColor = true;
            this.saveButton.Click += new System.EventHandler(this.button2_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(238, 175);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(84, 71);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // turnLabel
            // 
            this.turnLabel.AutoSize = true;
            this.turnLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.turnLabel.Location = new System.Drawing.Point(12, 193);
            this.turnLabel.Name = "turnLabel";
            this.turnLabel.Size = new System.Drawing.Size(0, 24);
            this.turnLabel.TabIndex = 7;
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(574, 410);
            this.Controls.Add(this.turnLabel);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.saveButton);
            this.Controls.Add(this.rollButton);
            this.Controls.Add(this.playerPanel4);
            this.Controls.Add(this.playerPanel3);
            this.Controls.Add(this.playerPanel2);
            this.Controls.Add(this.playerPanel1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form3";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form3";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form3_FormClosing);
            this.Load += new System.EventHandler(this.Form3_Load);
            this.playerPanel1.ResumeLayout(false);
            this.playerPanel1.PerformLayout();
            this.playerPanel2.ResumeLayout(false);
            this.playerPanel2.PerformLayout();
            this.playerPanel3.ResumeLayout(false);
            this.playerPanel3.PerformLayout();
            this.playerPanel4.ResumeLayout(false);
            this.playerPanel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label bankLabel1;
        private System.Windows.Forms.Label scoreLabel1;
        private System.Windows.Forms.Label bankLabel2;
        private System.Windows.Forms.Label scoreLabel2;
        private System.Windows.Forms.Label bankLabel3;
        private System.Windows.Forms.Label scoreLabel3;
        private System.Windows.Forms.Label bankLabel4;
        private System.Windows.Forms.Label scoreLabel4;
        private System.Windows.Forms.Button rollButton;
        private System.Windows.Forms.Button saveButton;
        public System.Windows.Forms.Label nameLabel1;
        public System.Windows.Forms.Label nameLabel2;
        public System.Windows.Forms.Label nameLabel3;
        public System.Windows.Forms.Label nameLabel4;
        private System.Windows.Forms.Label bank1;
        private System.Windows.Forms.Label score1;
        private System.Windows.Forms.Label bank2;
        private System.Windows.Forms.Label score2;
        private System.Windows.Forms.Label bank3;
        private System.Windows.Forms.Label score3;
        private System.Windows.Forms.Label bank4;
        private System.Windows.Forms.Label score4;
        private System.Windows.Forms.PictureBox pictureBox1;
        public System.Windows.Forms.Panel playerPanel1;
        public System.Windows.Forms.Panel playerPanel2;
        public System.Windows.Forms.Panel playerPanel3;
        public System.Windows.Forms.Panel playerPanel4;
        public System.Windows.Forms.Label turnLabel;
    }
}