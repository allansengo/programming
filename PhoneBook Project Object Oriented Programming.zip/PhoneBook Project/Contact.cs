﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ITPoland_Project_4
{
    class Contact
    {
        public string name;
        public string middleName;
        public string lastName;
        public long phoneNumber;
        public string address;
        public string gender;
        public string pathImage;

        public Contact(string name, string middleName, string lastName, long phoneNumber, string address, string gender, string pathImage) 
        {
            this.name = name;
            this.middleName = middleName;
            this.lastName = lastName;
            this.phoneNumber = phoneNumber;
            this.address = address;
            this.gender = gender;
            this.pathImage = pathImage;
        }

    }
}
