from socket import socket, AF_INET, SOCK_STREAM

host = "localhost"
port = 2223
addr = (host, port)

TCPSock = socket(AF_INET, SOCK_STREAM)
TCPSock.connect(addr)

while True:
    data = input(">> ")
    if not data:
        break
    else:
        bin_data = data.encode()
        if(TCPSock.send(bin_data)):
            print(f"Sending message '{data}' to {addr}.")
TCPSock.close()

