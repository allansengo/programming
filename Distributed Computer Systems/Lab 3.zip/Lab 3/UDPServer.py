from socket import socket, AF_INET, SOCK_DGRAM

# Set the socket parameters
host = "127.0.0.1" #or host = "localhost"
port = 2223
buf_size = 1024
addr = (host, port)

# Create socket and bind to address
UDPSock = socket(AF_INET, SOCK_DGRAM)
UDPSock.bind(addr)

# Receive messages
while True:
    bin_data, addr = UDPSock.recvfrom(buf_size)
    data = bin_data.decode()
    if(data == "\quit"):
        print("Quiting!")
        break
    else:
        print(f"Received message '{data}' from {addr}.")

UDPSock.close()

