﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ITPoland_Project_3
{
    public partial class Form2 : Form
    {
        public int numberOfPlayers;
        public int goal;
        String playerName1;
        String playerName2;
        String playerName3;
        String playerName4;
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            nameBox1.Enabled = false;
            nameBox2.Enabled = false;
            nameBox3.Enabled = false;
            nameBox4.Enabled = false;
            colorButton1.Enabled = false;
            colorButton2.Enabled = false;
            colorButton3.Enabled = false;
            colorButton4.Enabled = false;
            startButton.Enabled = false;
            colorButton1.BackColor = colorDialog1.Color;
            colorButton2.BackColor = colorDialog2.Color;
            colorButton3.BackColor = colorDialog3.Color;
            colorButton4.BackColor = colorDialog4.Color;
        }

        private void Form2_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            colorDialog1.AllowFullOpen = false;
            colorDialog1.ShowHelp = true;

            colorDialog1.Color = colorButton1.ForeColor;

            // Update the text box color if the user clicks OK 
            if (colorDialog1.ShowDialog() == DialogResult.OK)
                colorButton1.BackColor = colorDialog1.Color;
        }

        private void colorButton2_Click(object sender, EventArgs e)
        {
            colorDialog2.AllowFullOpen = false;
            colorDialog2.ShowHelp = true;

            colorDialog2.Color = colorButton2.ForeColor;

            // Update the text box color if the user clicks OK 
            if (colorDialog2.ShowDialog() == DialogResult.OK)
                colorButton2.BackColor = colorDialog2.Color;
        }

        private void colorButton3_Click(object sender, EventArgs e)
        {
            colorDialog3.AllowFullOpen = false;
            colorDialog3.ShowHelp = true;

            colorDialog3.Color = colorButton3.ForeColor;

            // Update the text box color if the user clicks OK 
            if (colorDialog3.ShowDialog() == DialogResult.OK)
                colorButton3.BackColor = colorDialog3.Color;
        }

        private void colorButton4_Click(object sender, EventArgs e)
        {
            colorDialog4.AllowFullOpen = false;
            colorDialog4.ShowHelp = true;

            colorDialog4.Color = colorButton4.ForeColor;

            // Update the text box color if the user clicks OK 
            if (colorDialog4.ShowDialog() == DialogResult.OK)
                colorButton4.BackColor = colorDialog4.Color;
        }

        public void nameBox1_TextChanged(object sender, EventArgs e)
        {

        }

        public void nameBox2_TextChanged(object sender, EventArgs e)
        {

        }

        public void nameBox3_TextChanged(object sender, EventArgs e)
        {

        }

        public void nameBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void startButton_Click(object sender, EventArgs e)
        {
            if (numberOfPlayers == 2)
            {
                if (nameBox1.Text != "" && nameBox2.Text != "")
                {
                    Form3 form3 = new Form3();
                    this.Hide();
                    form3.nameLabel1.Text = nameBox1.Text;
                    form3.nameLabel2.Text = nameBox2.Text;
                    form3.goal = goal;
                    form3.numberOfPlayers = numberOfPlayers;
                    playerName1 = nameBox1.Text;
                    playerName2 = nameBox2.Text;
                    form3.playerName1 = nameBox1.Text;
                    form3.playerName2 = nameBox2.Text;
                    form3.turnLabel.Text = "It's " + playerName1 + " turn.";
                    form3.playerPanel1.BackColor = colorButton1.BackColor;
                    form3.playerPanel2.BackColor = colorButton2.BackColor;
                    form3.playerPanel3.Visible = false;
                    form3.playerPanel4.Visible = false;
                    form3.ShowDialog();
                }
                else
                {
                    MessageBox.Show("Please enter name for players 1, 2");
                }
            }
            if (numberOfPlayers == 3)
            {
                if (nameBox1.Text != "" && nameBox2.Text != "" && nameBox3.Text != "")
                {
                    Form3 form3 = new Form3();
                    this.Hide();
                    form3.nameLabel1.Text = nameBox1.Text;
                    form3.nameLabel2.Text = nameBox2.Text;
                    form3.nameLabel3.Text = nameBox3.Text;
                    form3.goal = goal;
                    form3.numberOfPlayers = numberOfPlayers;
                    playerName1 = nameBox1.Text;
                    playerName2 = nameBox2.Text;
                    playerName3 = nameBox3.Text;
                    form3.playerName1 = nameBox1.Text;
                    form3.playerName2 = nameBox2.Text;
                    form3.playerName3 = nameBox3.Text;
                    form3.turnLabel.Text = "It's " + playerName1 + " turn.";
                    form3.playerPanel1.BackColor = colorButton1.BackColor;
                    form3.playerPanel2.BackColor = colorButton2.BackColor;
                    form3.playerPanel3.BackColor = colorButton3.BackColor;
                    form3.playerPanel4.Visible = false;
                    form3.ShowDialog();
                }
                else
                {
                    MessageBox.Show("Please enter name for players 1, 2, 3");
                }
            }
            if (numberOfPlayers == 4)
            {
                if (nameBox1.Text != "" && nameBox2.Text != "" && nameBox3.Text != "" && nameBox4.Text != "")
                {
                    Form3 form3 = new Form3();
                    this.Hide();
                    form3.nameLabel1.Text = nameBox1.Text;
                    form3.nameLabel2.Text = nameBox2.Text;
                    form3.nameLabel3.Text = nameBox3.Text;
                    form3.nameLabel4.Text = nameBox4.Text;
                    form3.goal = goal;
                    form3.numberOfPlayers = numberOfPlayers;
                    playerName1 = nameBox1.Text;
                    playerName2 = nameBox2.Text;
                    playerName3 = nameBox3.Text;
                    playerName4 = nameBox4.Text;
                    form3.playerName1 = nameBox1.Text;
                    form3.playerName2 = nameBox2.Text;
                    form3.playerName3 = nameBox3.Text;
                    form3.playerName4 = nameBox4.Text;
                    form3.turnLabel.Text = "It's " + playerName1 + " turn.";
                    form3.playerPanel1.BackColor = colorButton1.BackColor;
                    form3.playerPanel2.BackColor = colorButton2.BackColor;
                    form3.playerPanel3.BackColor = colorButton3.BackColor;
                    form3.playerPanel4.BackColor = colorButton4.BackColor;
                    form3.ShowDialog();
                }
                else
                {
                    MessageBox.Show("Please enter name for players 1, 2, 3, 4");
                }
            }
        }

        private void confirmButton_Click(object sender, EventArgs e)
        {
            if (numbertOfPlayersBox.Text != "" && Convert.ToInt32(numbertOfPlayersBox.Text) >= 2 && Convert.ToInt32(numbertOfPlayersBox.Text) <= 4 && Convert.ToInt32(goalBox.Text) > 0 && Convert.ToInt32(goalBox.Text) <= 50)
            {
                numberOfPlayers = Convert.ToInt32(numbertOfPlayersBox.Text);
                goal = Convert.ToInt32(goalBox.Text);
            }
            else
            {
                MessageBox.Show("Number of players must be within 2 and 4" + "\nAnd goal must be within 0 and 50");
            }
            
            if (numberOfPlayers == 2)
            {
                nameBox1.Enabled = true;
                nameBox2.Enabled = true;
                colorButton1.Enabled = true;
                colorButton2.Enabled = true;
                startButton.Enabled = true;
                numbertOfPlayersBox.Enabled = false;
                goalBox.Enabled = false;
                confirmButton.Enabled = false;
            }
            else if (numberOfPlayers == 3)
            {
                nameBox1.Enabled = true;
                nameBox2.Enabled = true;
                nameBox3.Enabled = true;
                colorButton1.Enabled = true;
                colorButton2.Enabled = true;
                colorButton3.Enabled = true;
                startButton.Enabled = true;
                numbertOfPlayersBox.Enabled = false;
                goalBox.Enabled = false;
                confirmButton.Enabled = false;
            }
            else if (numberOfPlayers == 4)
            {
                nameBox1.Enabled = true;
                nameBox2.Enabled = true;
                nameBox3.Enabled = true;
                nameBox4.Enabled = true;
                colorButton1.Enabled = true;
                colorButton2.Enabled = true;
                colorButton3.Enabled = true;
                colorButton4.Enabled = true;
                startButton.Enabled = true;
                numbertOfPlayersBox.Enabled = false;
                goalBox.Enabled = false;
                confirmButton.Enabled = false;
            }
        }
    }
}
