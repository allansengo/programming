from threading import Thread, Lock


x = 0.0
lck = Lock()


def fun():
    global x
    for _ in range(100000):
        #with lck:
            x += 1.0


def main():
    threads = [Thread(target=fun) for _ in range(32)]
    for thread in threads: thread.start()
    for thread in threads: thread.join()
    print(f"x = {x}")


if __name__ == "__main__":
    main()

