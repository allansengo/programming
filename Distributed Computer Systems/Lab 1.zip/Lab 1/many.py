from threading import Thread


def fun(number):
    print(f"Thread number {number} is running...\n", end="")


def main():
    threads = [Thread(target=fun, args=(i,)) for i in range(32)]
    for thread in threads: thread.start()
    for thread in threads: thread.join()


if __name__ == "__main__":
    main()

