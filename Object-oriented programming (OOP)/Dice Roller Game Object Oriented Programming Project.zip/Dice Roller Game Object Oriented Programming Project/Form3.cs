﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ITPoland_Project_3
{
    public partial class Form3 : Form
    {
        Form2 form2 = new Form2();
        public String playerName1;
        public String playerName2;
        public String playerName3;
        public String playerName4;
        public int numberOfPlayers;
        public int goal;
        public int scorePlayer1;
        public int scorePlayer2;
        public int scorePlayer3;
        public int scorePlayer4;
        public int bank;
        public int bankOrder = 1;
        public int scoreOrder = 1;
        public int turn = 2;
        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (numberOfPlayers == 2)
            {
                if (turn == 1)
                {
                    turnLabel.Text = "It's " + playerName1 + " turn.";
                    turn++;
                }
                else
                {
                    turnLabel.Text = "It's " + playerName2 + " turn.";
                    turn--;
                }

                if (scoreOrder == 1)
                {
                    int score = Convert.ToInt32(score1.Text) + Convert.ToInt32(bank1.Text);
                    score1.Text = score + "";
                    bank1.Text = 0 + "";
                    scoreOrder++;
                }
                else
                {
                    int score = Convert.ToInt32(score2.Text) + Convert.ToInt32(bank2.Text);
                    score2.Text = score + "";
                    bank2.Text = 0 + "";
                    scoreOrder--;
                }
            }

            if (numberOfPlayers == 3)
            {
                if (turn == 1)
                {
                    turnLabel.Text = "It's " + playerName1 + " turn.";
                    turn++;
                }
                else if (turn == 2)
                {
                    turnLabel.Text = "It's " + playerName2 + " turn.";
                    turn++;
                }
                else
                {
                    turnLabel.Text = "It's " + playerName3 + " turn.";
                    turn = turn - 2;
                }


                if (scoreOrder == 1)
                {
                    int score = Convert.ToInt32(score1.Text) + Convert.ToInt32(bank1.Text);
                    score1.Text = score + "";
                    bank1.Text = 0 + "";
                    scoreOrder++;
                }
                else if (scoreOrder == 2)
                {
                    int score = Convert.ToInt32(score2.Text) + Convert.ToInt32(bank2.Text);
                    score2.Text = score + "";
                    bank2.Text = 0 + "";
                    scoreOrder++;
                }
                else
                {
                    int score = Convert.ToInt32(score3.Text) + Convert.ToInt32(bank3.Text);
                    score3.Text = score + "";
                    bank3.Text = 0 + "";
                    scoreOrder = scoreOrder - 2;
                }
            }

            if (numberOfPlayers == 4)
            {
                if (turn == 1)
                {
                    turnLabel.Text = "It's " + playerName1 + " turn.";
                    turn++;
                }
                else if (turn == 2)
                {
                    turnLabel.Text = "It's " + playerName2 + " turn.";
                    turn++;
                }
                else if (turn == 3)
                {
                    turnLabel.Text = "It's " + playerName3 + " turn.";
                    turn++;
                }
                else
                {
                    turnLabel.Text = "It's " + playerName4 + " turn.";
                    turn = turn - 3;
                }


                if (scoreOrder == 1)
                {
                    int score = Convert.ToInt32(score1.Text) + Convert.ToInt32(bank1.Text);
                    score1.Text = score + "";
                    bank1.Text = 0 + "";
                    scoreOrder++;
                }
                else if (scoreOrder == 2)
                {
                    int score = Convert.ToInt32(score2.Text) + Convert.ToInt32(bank2.Text);
                    score2.Text = score + "";
                    bank2.Text = 0 + "";
                    scoreOrder++;
                }
                else if (scoreOrder == 3)
                {
                    int score = Convert.ToInt32(score3.Text) + Convert.ToInt32(bank3.Text);
                    score3.Text = score + "";
                    bank3.Text = 0 + "";
                    scoreOrder++;
                }
                else
                {
                    int score = Convert.ToInt32(score4.Text) + Convert.ToInt32(bank4.Text);
                    score4.Text = score + "";
                    bank4.Text = 0 + "";
                    scoreOrder = scoreOrder - 3;
                }
            }

            if (Convert.ToInt32(score1.Text) >= goal)
            {
                MessageBox.Show(nameLabel1.Text + " win the game!");
                Application.Exit();
            }
            else if (Convert.ToInt32(score2.Text) >= goal)
            {
                MessageBox.Show(nameLabel2.Text + " win the game!");
                Application.Exit();
            }
            else if (Convert.ToInt32(score3.Text) >= goal)
            {
                MessageBox.Show(nameLabel3.Text + " win the game!");
                Application.Exit();
            }
            else if (Convert.ToInt32(score4.Text) >= goal)
            {
                MessageBox.Show(nameLabel4.Text + " win the game!");
                Application.Exit();
            }

            rollButton.Enabled = true;
            saveButton.Enabled = false;
        }

        private void playerNameLabel1_Click(object sender, EventArgs e)
        {

        }

        private void Form3_Load(object sender, EventArgs e)
        {
            saveButton.Enabled = false;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void playerPanel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void rollButton_Click(object sender, EventArgs e)
        {
            if (numberOfPlayers == 2)
            {
                if (bankOrder == 1)
                {
                    bankOrder++;
                    Random random = new Random();
                    bank = random.Next(1, 7);
                    if (bank == 1)
                    {
                        pictureBox1.Image = Properties.Resources.page1;
                        bank1.Text = bank + "";
                    }
                    else if (bank == 2)
                    {
                        pictureBox1.Image = Properties.Resources.page2;
                        bank1.Text = bank + "";
                    }
                    else if (bank == 3)
                    {
                        pictureBox1.Image = Properties.Resources.page3;
                        bank1.Text = bank + "";
                    }
                    else if (bank == 4)
                    {
                        pictureBox1.Image = Properties.Resources.page4;
                        bank1.Text = bank + "";
                    }
                    else if (bank == 5)
                    {
                        pictureBox1.Image = Properties.Resources.page5;
                        bank1.Text = bank + "";
                    }
                    else
                    {
                        pictureBox1.Image = Properties.Resources.page6;
                        bank1.Text = bank + "";
                    }
                }
                else
                {
                    bankOrder--;
                    Random random = new Random();
                    bank = random.Next(1, 7);
                    if (bank == 1)
                    {
                        pictureBox1.Image = Properties.Resources.page1;
                        bank2.Text = bank + "";
                    }
                    else if (bank == 2)
                    {
                        pictureBox1.Image = Properties.Resources.page2;
                        bank2.Text = bank + "";
                    }
                    else if (bank == 3)
                    {
                        pictureBox1.Image = Properties.Resources.page3;
                        bank2.Text = bank + "";
                    }
                    else if (bank == 4)
                    {
                        pictureBox1.Image = Properties.Resources.page4;
                        bank2.Text = bank + "";
                    }
                    else if (bank == 5)
                    {
                        pictureBox1.Image = Properties.Resources.page5;
                        bank2.Text = bank + "";
                    }
                    else
                    {
                        pictureBox1.Image = Properties.Resources.page6;
                        bank2.Text = bank + "";
                    }
                }               
            }

            if (numberOfPlayers == 3)
            {
                if (bankOrder == 1)
                {
                    bankOrder++;
                    Random random = new Random();
                    bank = random.Next(1, 7);
                    if (bank == 1)
                    {
                        pictureBox1.Image = Properties.Resources.page1;
                        bank1.Text = bank + "";
                    }
                    else if (bank == 2)
                    {
                        pictureBox1.Image = Properties.Resources.page2;
                        bank1.Text = bank + "";
                    }
                    else if (bank == 3)
                    {
                        pictureBox1.Image = Properties.Resources.page3;
                        bank1.Text = bank + "";
                    }
                    else if (bank == 4)
                    {
                        pictureBox1.Image = Properties.Resources.page4;
                        bank1.Text = bank + "";
                    }
                    else if (bank == 5)
                    {
                        pictureBox1.Image = Properties.Resources.page5;
                        bank1.Text = bank + "";
                    }
                    else
                    {
                        pictureBox1.Image = Properties.Resources.page6;
                        bank1.Text = bank + "";
                    }
                }
                else if (bankOrder == 2)
                {
                    bankOrder++;
                    Random random = new Random();
                    bank = random.Next(1, 7);
                    if (bank == 1)
                    {
                        pictureBox1.Image = Properties.Resources.page1;
                        bank2.Text = bank + "";
                    }
                    else if (bank == 2)
                    {
                        pictureBox1.Image = Properties.Resources.page2;
                        bank2.Text = bank + "";
                    }
                    else if (bank == 3)
                    {
                        pictureBox1.Image = Properties.Resources.page3;
                        bank2.Text = bank + "";
                    }
                    else if (bank == 4)
                    {
                        pictureBox1.Image = Properties.Resources.page4;
                        bank2.Text = bank + "";
                    }
                    else if (bank == 5)
                    {
                        pictureBox1.Image = Properties.Resources.page5;
                        bank2.Text = bank + "";
                    }
                    else
                    {
                        pictureBox1.Image = Properties.Resources.page6;
                        bank2.Text = bank + "";
                    }
                }
                else
                {
                    bankOrder = bankOrder - 2;
                    Random random = new Random();
                    bank = random.Next(1, 7);
                    if (bank == 1)
                    {
                        pictureBox1.Image = Properties.Resources.page1;
                        bank3.Text = bank + "";
                    }
                    else if (bank == 2)
                    {
                        pictureBox1.Image = Properties.Resources.page2;
                        bank3.Text = bank + "";
                    }
                    else if (bank == 3)
                    {
                        pictureBox1.Image = Properties.Resources.page3;
                        bank3.Text = bank + "";
                    }
                    else if (bank == 4)
                    {
                        pictureBox1.Image = Properties.Resources.page4;
                        bank3.Text = bank + "";
                    }
                    else if (bank == 5)
                    {
                        pictureBox1.Image = Properties.Resources.page5;
                        bank3.Text = bank + "";
                    }
                    else
                    {
                        pictureBox1.Image = Properties.Resources.page6;
                        bank3.Text = bank + "";
                    }
                }
            }

            if (numberOfPlayers == 4)
            {
                if (bankOrder == 1)
                {
                    bankOrder++;
                    Random random = new Random();
                    bank = random.Next(1, 7);
                    if (bank == 1)
                    {
                        pictureBox1.Image = Properties.Resources.page1;
                        bank1.Text = bank + "";
                    }
                    else if (bank == 2)
                    {
                        pictureBox1.Image = Properties.Resources.page2;
                        bank1.Text = bank + "";
                    }
                    else if (bank == 3)
                    {
                        pictureBox1.Image = Properties.Resources.page3;
                        bank1.Text = bank + "";
                    }
                    else if (bank == 4)
                    {
                        pictureBox1.Image = Properties.Resources.page4;
                        bank1.Text = bank + "";
                    }
                    else if (bank == 5)
                    {
                        pictureBox1.Image = Properties.Resources.page5;
                        bank1.Text = bank + "";
                    }
                    else
                    {
                        pictureBox1.Image = Properties.Resources.page6;
                        bank1.Text = bank + "";
                    }
                }
                else if (bankOrder == 2)
                {
                    bankOrder++;
                    Random random = new Random();
                    bank = random.Next(1, 7);
                    if (bank == 1)
                    {
                        pictureBox1.Image = Properties.Resources.page1;
                        bank2.Text = bank + "";
                    }
                    else if (bank == 2)
                    {
                        pictureBox1.Image = Properties.Resources.page2;
                        bank2.Text = bank + "";
                    }
                    else if (bank == 3)
                    {
                        pictureBox1.Image = Properties.Resources.page3;
                        bank2.Text = bank + "";
                    }
                    else if (bank == 4)
                    {
                        pictureBox1.Image = Properties.Resources.page4;
                        bank2.Text = bank + "";
                    }
                    else if (bank == 5)
                    {
                        pictureBox1.Image = Properties.Resources.page5;
                        bank2.Text = bank + "";
                    }
                    else
                    {
                        pictureBox1.Image = Properties.Resources.page6;
                        bank2.Text = bank + "";
                    }
                }
                else if (bankOrder == 3)
                {
                    bankOrder++;
                    Random random = new Random();
                    bank = random.Next(1, 7);
                    if (bank == 1)
                    {
                        pictureBox1.Image = Properties.Resources.page1;
                        bank3.Text = bank + "";
                    }
                    else if (bank == 2)
                    {
                        pictureBox1.Image = Properties.Resources.page2;
                        bank3.Text = bank + "";
                    }
                    else if (bank == 3)
                    {
                        pictureBox1.Image = Properties.Resources.page3;
                        bank3.Text = bank + "";
                    }
                    else if (bank == 4)
                    {
                        pictureBox1.Image = Properties.Resources.page4;
                        bank3.Text = bank + "";
                    }
                    else if (bank == 5)
                    {
                        pictureBox1.Image = Properties.Resources.page5;
                        bank3.Text = bank + "";
                    }
                    else
                    {
                        pictureBox1.Image = Properties.Resources.page6;
                        bank3.Text = bank + "";
                    }
                }
                else
                {
                    bankOrder = bankOrder - 3;
                    Random random = new Random();
                    bank = random.Next(1, 7);
                    if (bank == 1)
                    {
                        pictureBox1.Image = Properties.Resources.page1;
                        bank4.Text = bank + "";
                    }
                    else if (bank == 2)
                    {
                        pictureBox1.Image = Properties.Resources.page2;
                        bank4.Text = bank + "";
                    }
                    else if (bank == 3)
                    {
                        pictureBox1.Image = Properties.Resources.page3;
                        bank4.Text = bank + "";
                    }
                    else if (bank == 4)
                    {
                        pictureBox1.Image = Properties.Resources.page4;
                        bank4.Text = bank + "";
                    }
                    else if (bank == 5)
                    {
                        pictureBox1.Image = Properties.Resources.page5;
                        bank4.Text = bank + "";
                    }
                    else
                    {
                        pictureBox1.Image = Properties.Resources.page6;
                        bank4.Text = bank + "";
                    }
                }
            }
            rollButton.Enabled = false;
            saveButton.Enabled = true;
        }
    }
}
