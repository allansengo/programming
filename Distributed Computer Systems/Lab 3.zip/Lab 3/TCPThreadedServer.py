from socket import socket, AF_INET, SOCK_STREAM
from threading import Thread


def handle_connection(client_sock, addr):
    while True:
        bin_data = client_sock.recv(buf_size)
        data = bin_data.decode()
        if data == "\quit":
            print(f"Closing the connection with {addr}.")
            break
        else:
            print(f"Received message '{data}' from {addr}.")

    client_sock.close()


host = "localhost"
port = 2224
buf_size = 1024
addr = (host, port)

TCPSock = socket(AF_INET, SOCK_STREAM)
TCPSock.bind(addr)

TCPSock.listen(10)
while True:
    client_sock, addr = TCPSock.accept()
    print(f"Accepted the connection from {addr}.")
    t = Thread(target=handle_connection, args=(client_sock, addr))
    t.start()

