from threading import Thread, BoundedSemaphore
from time import sleep
from random import random


class Philosopher(Thread):
    def __init__(self, number, forks):
        self.number = number
        self.forks = forks
        self.left = number
        self.right = (number + 1) % len(forks)
        super().__init__()

    def think(self):
        print(f"The philosopher {self.number} starts thinking...")
        print(f"The philosopher {self.number} has become hungry!")

    def eat(self):
        print(f"The philosopher {self.number} starts eating.")
        sleep(random())
        print(f"The philosopher {self.number} has finished the consumption.")

    def run(self):
        while True:
            self.think()
            if self.number < len(self.forks) - 1:
                with self.forks[self.left]:
                    with self.forks[self.right]:
                        self.eat()
            else:
                with self.forks[self.right]:
                    with self.forks[self.left]:
                        self.eat()


def main():
    num_philosophers = 5
    forks = [BoundedSemaphore(1) for _ in range(num_philosophers)]
    philosophers = [Philosopher(i, forks) for i in range(num_philosophers)]
    for philo in philosophers: philo.start()
    for philo in philosophers: philo.join()


if __name__ == "__main__":
    main()

