﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace ITPoland_Project_4
{
    public partial class Form3 : Form
    {
        Bitmap image;
        public static string path = Path.GetFileName("imageNotAvailable.jpg");
        string name;
        string middleName;
        string lastName;
        long phoneNumber;
        string address;
        string gender;
        Contact contact;
        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            
        }

        private void Form3_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog open_dialog = new OpenFileDialog();
            open_dialog.Filter = "Image Files(*.BMP;*.JPG;*.GIF;*.PNG)|*.BMP;*.JPG;*.GIF;*.PNG|All files (*.*)|*.*";
            if (open_dialog.ShowDialog() == DialogResult.OK) 
            {
                try
                {
                    path = open_dialog.FileName;
                    image = new Bitmap(open_dialog.FileName);
                    pictureBox1.Image = image;
                    pictureBox1.Invalidate();
                }
                catch
                {
                    DialogResult rezult = MessageBox.Show("Unable to open the selected file",
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void addButton_Click(object sender, EventArgs e)
        {
            if (nameBox.Text != "" && lastNameBox.Text != "" && phoneNumberBox.Text != "" && Convert.ToInt64(phoneNumberBox.Text) > 0 && addressBox.Text != "" && (maleButton.Checked || femaleButton.Checked)) 
            {
                //The Contact information
                name = nameBox.Text;
                middleName = middleNameBox.Text;
                lastName = lastNameBox.Text;
                address = addressBox.Text;
                phoneNumber = Convert.ToInt64(phoneNumberBox.Text);

                //Creating copy of the image
                if (path != "imageNotAvailable.jpg"){
                    File.Copy(path, Path.Combine(Path.GetFileName(path)), true);
                }
                //The path of the image
                path = Path.GetFileName(path);

                if (maleButton.Checked)
                {
                    gender = "Male";
                    contact = new Contact(name, middleName, lastName, phoneNumber, address, gender, path);
                }
                else if (femaleButton.Checked)
                {
                    gender = "Female";
                    contact = new Contact(name, middleName, lastName, phoneNumber, address, gender, path);
                }

                FileStream fs = new FileStream("contacts.txt", FileMode.Append, FileAccess.Write);
                StreamWriter sw = new StreamWriter(fs);

                sw.WriteLine("+++++++++++++++");
                sw.WriteLine(contact.name);
                sw.WriteLine(contact.middleName);
                sw.WriteLine(contact.lastName);
                sw.WriteLine(contact.phoneNumber);
                sw.WriteLine(contact.address);
                sw.WriteLine(contact.gender);
                sw.WriteLine(contact.pathImage);

                sw.Close();
                fs.Close();

                Contacts.contacts.Add(new Contact(name, middleName, lastName, phoneNumber, address, gender, path));

                MessageBox.Show("Contact successfully added!");


                nameBox.Text = "";
                middleNameBox.Text = "";
                lastNameBox.Text = "";
                phoneNumberBox.Text = "";
                addressBox.Text = "";
                maleButton.Checked = false;
                femaleButton.Checked = false;
                pictureBox1.Image = Properties.Resources.imageNotAvailable;
            }
            else
            {
                MessageBox.Show("Please enter information about the contact!");
            }          
        }

        private void backToMenuButton_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            this.Hide();
            form1.ShowDialog();
        }
    }
}
