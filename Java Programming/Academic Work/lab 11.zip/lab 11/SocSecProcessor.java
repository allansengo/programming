import java.util.Scanner;

public class SocSecProcessor {
        
        // main method
        public static void main(String[] args)
        {
                // declaring variables
                String name, ssn;
                Scanner input = new Scanner(System.in);
                char repeat = 'y'; // loop variable
                while(repeat == 'y') // loop until y is entered
                {
                        // input the name
                        System.out.print("Name? ");
                        name = input.nextLine();
                        // input the ssn
                        System.out.print("SSN? ");
                        ssn = input.nextLine();
                        // try-catch block to check if ssn is valid
                        try 
                        {
                                boolean valid = isValid(ssn);
                                if(valid)
                                        System.out.println(name + " " + ssn + " " + "is valid");
                        }
                        // catch block to catch the exception
                        catch (SocSecException e) 
                        {
                                System.out.println(e.getMessage());
                        }
                        System.out.print("Continue? ");
                        repeat = input.nextLine().toLowerCase().charAt(0);
                }
                
                
        }
        
        /**
         * Method to check validity of SSN
         * @param SSN
         * @return boolean
         * @throws SocSecException
         */
        public static boolean isValid(String ssn) throws SocSecException
        {
                // calculate the length of ssn
                int ssn_len = ssn.length();
                // check if length of ssn is exactly 11
                // if not then throw exception
                if(ssn_len != 11)
                        throw new SocSecException("wrong number of characters");

                // loop through each character of ssn
                for(int i = 0; i < ssn_len; i++)
                {
                        // get the character at i
                        char ch = ssn.charAt(i);
                        // check the character at index 0,1,2, 4,5, 7,8,9,10
                        // to check for valid digits
                        if( (i >= 0 && i <= 2) || i == 4 || i == 5 || (i >= 7 && i <= 10) )
                        {
                                // if not valid digit then throw exception
                                if(!(ch >= '0' && ch <= '9'))
                                {
                                        throw new SocSecException("contains a character that is not a digit");
                                }
                        }
                        // check if index is 3 or 6
                        else if(i == 3 || i == 6)
                        {
                                // if not dash then it means
                                // dashes are at wrong place and throw exception
                                if(ch != '-')
                                        throw new SocSecException("dashes at wrong positions");
                                        
                        }
                }
                // finally return true if no exception is thrown
                return true;
        }

}

