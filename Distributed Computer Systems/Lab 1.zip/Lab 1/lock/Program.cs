﻿using System;
using System.Threading;

class Program
{
	static double x = 0.0;
	static Object lck = new Object();

	static void Fun()
	{
		for (int i = 0; i < 100000; ++i) {
			lock(lck) {
				x += 1.0;
			}
		}
	}

        static void Main(string[] args)
        {
		int num_threads = 32;
		Thread[] threads = new Thread[num_threads];
		for (int i = 0; i < num_threads; ++i) {
			threads[i] = new Thread(Fun);
		}
		foreach (var thread in threads) thread.Start();
		foreach (var thread in threads) thread.Join();
		Console.WriteLine($"x = {x}");
        }
}

