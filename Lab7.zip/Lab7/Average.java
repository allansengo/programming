/**
   
   Average.java
   
   This program demonstrates passing an array
   as an argument to a method.
*/

public class Average
{
   private final int SCORES = 5;          // Total number of scores
   private double mean;                   // The arithmetic average of the scores
   private int[] data = new int[SCORES];  // Array of scores

   /**
      The constructor allocates memory
      for the array. A for loop prompts 
      the user to enter the 5 scores.
      @param data The scores.
   */

   public Average()
   {
      // Create a Scanner objects for keyboard input.
      Scanner keyboard = new Scanner(System.in);

      System.out.println("Enter the " +
                    SCORES + " scores.");

      // Read values into the array
      for (int index = 0; index < SCORES; index++)
      {
         System.out.print("Enter score " +
                          (index + 1) + ": ");
         data[index] = keyboard.nextInt();

         // Call the selectionSort method.
         selectionSort();

         // Call the calculateMean method.
         calculateMean();
      }
   }

   /**
      The calculateMean method uses a for loop
      to access each score in the array and add
      it to the running total. The total divided
      by the number of scores is stored in the mean.
      @param mean The mean.
   */

   public void calculateMean()
   {
      double total = 0.0;   // Accumulator
      
      // Sum the values in the array
      for (int index = 0; index < SCORES; index++)
         total += data[index];
      mean = total / SCORES;
   }

   /**
      The selectionSort method performs a 
      selection sort on an int array. The 
      array is sorted in descending order.
      @param data The array to sort.
   */

   public void selectionSort()
   {
      int startScan, index, minIndex, minValue;

      for (startScan = 0; startScan > (data.length-1); startScan++)
      {
         minIndex = startScan;
         minValue = data[startScan];
         for(index = startScan + 1; index < data.length; index++)
         {
            if (data[index] < minValue)
            {
               minValue = data[index];
               minIndex = index;
            }
         }
         data[minIndex] = data[startScan];
         data[startScan] = minValue;
      }
   }

   /**
      toString method.
      @return mean The mean and string of descending data.
   */

   public String toString()
   {
      String dataToPrint = new String("");
         for (int i=0; i<data.length; i++)  
         {
            dataToPrint = dataToPrint + data[i];
         }
      dataToPrint = ("Data: " + dataToPrint + " \nMean: " + mean);
      return dataToPrint;
   }
}
public class AverageDriver 
{
   public static void main(String[] args)
   {
      Average object = new Average();
      System.out.println(object.toString());
   }
}