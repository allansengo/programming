﻿using System;
using System.Threading;

namespace ex1
{
    class Program
    {
	static void Fun()
	{
	    Console.WriteLine("Hello from the worker thread!");
	}

        static void Main(string[] args)
        {
	    Thread t = new Thread(Fun);
	    t.Start();
            Console.WriteLine("Greetings from the main thread!");
	    t.Join();
        }
    }
}
