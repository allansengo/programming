﻿
namespace Calculator_Project
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtDisplay = new System.Windows.Forms.TextBox();
            this.btn1 = new System.Windows.Forms.Button();
            this.btn4 = new System.Windows.Forms.Button();
            this.btn7 = new System.Windows.Forms.Button();
            this.btnpoint = new System.Windows.Forms.Button();
            this.btn0 = new System.Windows.Forms.Button();
            this.btn8 = new System.Windows.Forms.Button();
            this.btn5 = new System.Windows.Forms.Button();
            this.btn2 = new System.Windows.Forms.Button();
            this.btnequal = new System.Windows.Forms.Button();
            this.btn9 = new System.Windows.Forms.Button();
            this.btn6 = new System.Windows.Forms.Button();
            this.btn3 = new System.Windows.Forms.Button();
            this.btntimes = new System.Windows.Forms.Button();
            this.btnminus = new System.Windows.Forms.Button();
            this.btnplus = new System.Windows.Forms.Button();
            this.btnfactional = new System.Windows.Forms.Button();
            this.btnend = new System.Windows.Forms.Button();
            this.btndivide = new System.Windows.Forms.Button();
            this.btnpower = new System.Windows.Forms.Button();
            this.btnpercent = new System.Windows.Forms.Button();
            this.btnclear = new System.Windows.Forms.Button();
            this.btnbackspace = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // txtDisplay
            // 
            this.txtDisplay.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDisplay.Location = new System.Drawing.Point(47, 51);
            this.txtDisplay.Name = "txtDisplay";
            this.txtDisplay.Size = new System.Drawing.Size(306, 40);
            this.txtDisplay.TabIndex = 0;
            this.txtDisplay.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtDisplay.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // btn1
            // 
            this.btn1.BackColor = System.Drawing.Color.Black;
            this.btn1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn1.ForeColor = System.Drawing.Color.White;
            this.btn1.Location = new System.Drawing.Point(47, 232);
            this.btn1.Name = "btn1";
            this.btn1.Size = new System.Drawing.Size(61, 47);
            this.btn1.TabIndex = 1;
            this.btn1.Text = "1";
            this.btn1.UseVisualStyleBackColor = false;
            this.btn1.Click += new System.EventHandler(this.NumericValue);
            // 
            // btn4
            // 
            this.btn4.BackColor = System.Drawing.Color.Black;
            this.btn4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn4.ForeColor = System.Drawing.Color.White;
            this.btn4.Location = new System.Drawing.Point(47, 287);
            this.btn4.Name = "btn4";
            this.btn4.Size = new System.Drawing.Size(61, 51);
            this.btn4.TabIndex = 13;
            this.btn4.Text = "4";
            this.btn4.UseVisualStyleBackColor = false;
            this.btn4.Click += new System.EventHandler(this.NumericValue);
            // 
            // btn7
            // 
            this.btn7.BackColor = System.Drawing.Color.Black;
            this.btn7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn7.ForeColor = System.Drawing.Color.White;
            this.btn7.Location = new System.Drawing.Point(47, 347);
            this.btn7.Name = "btn7";
            this.btn7.Size = new System.Drawing.Size(61, 49);
            this.btn7.TabIndex = 14;
            this.btn7.Text = "7";
            this.btn7.UseVisualStyleBackColor = false;
            this.btn7.Click += new System.EventHandler(this.NumericValue);
            // 
            // btnpoint
            // 
            this.btnpoint.BackColor = System.Drawing.Color.Black;
            this.btnpoint.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnpoint.ForeColor = System.Drawing.Color.White;
            this.btnpoint.Location = new System.Drawing.Point(47, 408);
            this.btnpoint.Name = "btnpoint";
            this.btnpoint.Size = new System.Drawing.Size(61, 50);
            this.btnpoint.TabIndex = 15;
            this.btnpoint.Text = ".";
            this.btnpoint.UseVisualStyleBackColor = false;
            this.btnpoint.Click += new System.EventHandler(this.NumericValue);
            // 
            // btn0
            // 
            this.btn0.BackColor = System.Drawing.Color.Black;
            this.btn0.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn0.ForeColor = System.Drawing.Color.White;
            this.btn0.Location = new System.Drawing.Point(134, 408);
            this.btn0.Name = "btn0";
            this.btn0.Size = new System.Drawing.Size(61, 50);
            this.btn0.TabIndex = 19;
            this.btn0.Text = "0";
            this.btn0.UseVisualStyleBackColor = false;
            this.btn0.Click += new System.EventHandler(this.NumericValue);
            // 
            // btn8
            // 
            this.btn8.BackColor = System.Drawing.Color.Black;
            this.btn8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn8.ForeColor = System.Drawing.Color.White;
            this.btn8.Location = new System.Drawing.Point(134, 347);
            this.btn8.Name = "btn8";
            this.btn8.Size = new System.Drawing.Size(61, 49);
            this.btn8.TabIndex = 18;
            this.btn8.Text = "8";
            this.btn8.UseVisualStyleBackColor = false;
            this.btn8.Click += new System.EventHandler(this.NumericValue);
            // 
            // btn5
            // 
            this.btn5.BackColor = System.Drawing.Color.Black;
            this.btn5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn5.ForeColor = System.Drawing.Color.White;
            this.btn5.Location = new System.Drawing.Point(134, 287);
            this.btn5.Name = "btn5";
            this.btn5.Size = new System.Drawing.Size(61, 51);
            this.btn5.TabIndex = 17;
            this.btn5.Text = "5";
            this.btn5.UseVisualStyleBackColor = false;
            this.btn5.Click += new System.EventHandler(this.NumericValue);
            // 
            // btn2
            // 
            this.btn2.BackColor = System.Drawing.Color.Black;
            this.btn2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn2.ForeColor = System.Drawing.Color.White;
            this.btn2.Location = new System.Drawing.Point(134, 232);
            this.btn2.Name = "btn2";
            this.btn2.Size = new System.Drawing.Size(61, 47);
            this.btn2.TabIndex = 16;
            this.btn2.Text = "2";
            this.btn2.UseVisualStyleBackColor = false;
            this.btn2.Click += new System.EventHandler(this.NumericValue);
            // 
            // btnequal
            // 
            this.btnequal.BackColor = System.Drawing.Color.Black;
            this.btnequal.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnequal.ForeColor = System.Drawing.Color.White;
            this.btnequal.Location = new System.Drawing.Point(221, 408);
            this.btnequal.Name = "btnequal";
            this.btnequal.Size = new System.Drawing.Size(61, 50);
            this.btnequal.TabIndex = 23;
            this.btnequal.Text = "=";
            this.btnequal.UseVisualStyleBackColor = false;
            this.btnequal.Click += new System.EventHandler(this.button2_Click);
            // 
            // btn9
            // 
            this.btn9.BackColor = System.Drawing.Color.Black;
            this.btn9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn9.ForeColor = System.Drawing.Color.White;
            this.btn9.Location = new System.Drawing.Point(221, 347);
            this.btn9.Name = "btn9";
            this.btn9.Size = new System.Drawing.Size(61, 49);
            this.btn9.TabIndex = 22;
            this.btn9.Text = "9";
            this.btn9.UseVisualStyleBackColor = false;
            this.btn9.Click += new System.EventHandler(this.NumericValue);
            // 
            // btn6
            // 
            this.btn6.BackColor = System.Drawing.Color.Black;
            this.btn6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn6.ForeColor = System.Drawing.Color.White;
            this.btn6.Location = new System.Drawing.Point(221, 287);
            this.btn6.Name = "btn6";
            this.btn6.Size = new System.Drawing.Size(61, 51);
            this.btn6.TabIndex = 21;
            this.btn6.Text = "6";
            this.btn6.UseVisualStyleBackColor = false;
            this.btn6.Click += new System.EventHandler(this.NumericValue);
            // 
            // btn3
            // 
            this.btn3.BackColor = System.Drawing.Color.Black;
            this.btn3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn3.ForeColor = System.Drawing.Color.White;
            this.btn3.Location = new System.Drawing.Point(221, 232);
            this.btn3.Name = "btn3";
            this.btn3.Size = new System.Drawing.Size(61, 47);
            this.btn3.TabIndex = 20;
            this.btn3.Text = "3";
            this.btn3.UseVisualStyleBackColor = false;
            this.btn3.Click += new System.EventHandler(this.NumericValue);
            // 
            // btntimes
            // 
            this.btntimes.BackColor = System.Drawing.Color.DarkBlue;
            this.btntimes.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btntimes.ForeColor = System.Drawing.Color.White;
            this.btntimes.Location = new System.Drawing.Point(299, 287);
            this.btntimes.Name = "btntimes";
            this.btntimes.Size = new System.Drawing.Size(61, 51);
            this.btntimes.TabIndex = 27;
            this.btntimes.Text = "x";
            this.btntimes.UseVisualStyleBackColor = false;
            this.btntimes.Click += new System.EventHandler(this.Operational_function);
            // 
            // btnminus
            // 
            this.btnminus.BackColor = System.Drawing.Color.DarkBlue;
            this.btnminus.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnminus.ForeColor = System.Drawing.Color.White;
            this.btnminus.Location = new System.Drawing.Point(299, 232);
            this.btnminus.Name = "btnminus";
            this.btnminus.Size = new System.Drawing.Size(61, 47);
            this.btnminus.TabIndex = 26;
            this.btnminus.Text = "-";
            this.btnminus.UseVisualStyleBackColor = false;
            this.btnminus.Click += new System.EventHandler(this.Operational_function);
            // 
            // btnplus
            // 
            this.btnplus.BackColor = System.Drawing.Color.DarkBlue;
            this.btnplus.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnplus.ForeColor = System.Drawing.Color.White;
            this.btnplus.Location = new System.Drawing.Point(299, 347);
            this.btnplus.Name = "btnplus";
            this.btnplus.Size = new System.Drawing.Size(61, 111);
            this.btnplus.TabIndex = 25;
            this.btnplus.Text = "+";
            this.btnplus.UseVisualStyleBackColor = false;
            this.btnplus.Click += new System.EventHandler(this.Operational_function);
            // 
            // btnfactional
            // 
            this.btnfactional.BackColor = System.Drawing.Color.DarkBlue;
            this.btnfactional.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnfactional.ForeColor = System.Drawing.Color.White;
            this.btnfactional.Location = new System.Drawing.Point(299, 180);
            this.btnfactional.Name = "btnfactional";
            this.btnfactional.Size = new System.Drawing.Size(61, 45);
            this.btnfactional.TabIndex = 24;
            this.btnfactional.Text = "!";
            this.btnfactional.UseVisualStyleBackColor = false;
            this.btnfactional.Click += new System.EventHandler(this.btnfactional_Click);
            // 
            // btnend
            // 
            this.btnend.BackColor = System.Drawing.Color.Red;
            this.btnend.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnend.ForeColor = System.Drawing.Color.White;
            this.btnend.Location = new System.Drawing.Point(47, 123);
            this.btnend.Name = "btnend";
            this.btnend.Size = new System.Drawing.Size(61, 46);
            this.btnend.TabIndex = 28;
            this.btnend.Text = "End";
            this.btnend.UseVisualStyleBackColor = false;
            this.btnend.Click += new System.EventHandler(this.btnEnd_Click);
            // 
            // btndivide
            // 
            this.btndivide.BackColor = System.Drawing.Color.DarkBlue;
            this.btndivide.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btndivide.ForeColor = System.Drawing.Color.White;
            this.btndivide.Location = new System.Drawing.Point(47, 180);
            this.btndivide.Name = "btndivide";
            this.btndivide.Size = new System.Drawing.Size(61, 45);
            this.btndivide.TabIndex = 32;
            this.btndivide.Text = "/";
            this.btndivide.UseVisualStyleBackColor = false;
            this.btndivide.Click += new System.EventHandler(this.Operational_function);
            // 
            // btnpower
            // 
            this.btnpower.BackColor = System.Drawing.Color.DarkBlue;
            this.btnpower.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnpower.ForeColor = System.Drawing.Color.White;
            this.btnpower.Location = new System.Drawing.Point(221, 180);
            this.btnpower.Name = "btnpower";
            this.btnpower.Size = new System.Drawing.Size(61, 45);
            this.btnpower.TabIndex = 31;
            this.btnpower.Text = "^";
            this.btnpower.UseVisualStyleBackColor = false;
            this.btnpower.Click += new System.EventHandler(this.Operational_function);
            // 
            // btnpercent
            // 
            this.btnpercent.BackColor = System.Drawing.Color.DarkBlue;
            this.btnpercent.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnpercent.ForeColor = System.Drawing.Color.White;
            this.btnpercent.Location = new System.Drawing.Point(134, 180);
            this.btnpercent.Name = "btnpercent";
            this.btnpercent.Size = new System.Drawing.Size(61, 45);
            this.btnpercent.TabIndex = 30;
            this.btnpercent.Text = "%";
            this.btnpercent.UseVisualStyleBackColor = false;
            this.btnpercent.Click += new System.EventHandler(this.Operational_function);
            // 
            // btnclear
            // 
            this.btnclear.BackColor = System.Drawing.Color.DarkBlue;
            this.btnclear.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnclear.ForeColor = System.Drawing.Color.White;
            this.btnclear.Location = new System.Drawing.Point(134, 123);
            this.btnclear.Name = "btnclear";
            this.btnclear.Size = new System.Drawing.Size(61, 46);
            this.btnclear.TabIndex = 29;
            this.btnclear.Text = "Clear";
            this.btnclear.UseVisualStyleBackColor = false;
            this.btnclear.Click += new System.EventHandler(this.btnclear_Click);
            // 
            // btnbackspace
            // 
            this.btnbackspace.BackColor = System.Drawing.Color.DarkBlue;
            this.btnbackspace.Font = new System.Drawing.Font("Wingdings", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.btnbackspace.ForeColor = System.Drawing.Color.White;
            this.btnbackspace.Location = new System.Drawing.Point(221, 122);
            this.btnbackspace.Name = "btnbackspace";
            this.btnbackspace.Size = new System.Drawing.Size(61, 46);
            this.btnbackspace.TabIndex = 33;
            this.btnbackspace.Text = "";
            this.btnbackspace.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnbackspace.UseVisualStyleBackColor = false;
            this.btnbackspace.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(114, 490);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(208, 20);
            this.textBox1.TabIndex = 35;
            this.textBox1.Text = "Programmed by [GO TOGETER]";
            this.textBox1.TextChanged += new System.EventHandler(this.TextboxGroupname_TextChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DimGray;
            this.ClientSize = new System.Drawing.Size(412, 527);
            this.ControlBox = false;
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.btnbackspace);
            this.Controls.Add(this.btndivide);
            this.Controls.Add(this.btnpower);
            this.Controls.Add(this.btnpercent);
            this.Controls.Add(this.btnclear);
            this.Controls.Add(this.btnend);
            this.Controls.Add(this.btntimes);
            this.Controls.Add(this.btnminus);
            this.Controls.Add(this.btnplus);
            this.Controls.Add(this.btnfactional);
            this.Controls.Add(this.btnequal);
            this.Controls.Add(this.btn9);
            this.Controls.Add(this.btn6);
            this.Controls.Add(this.btn3);
            this.Controls.Add(this.btn0);
            this.Controls.Add(this.btn8);
            this.Controls.Add(this.btn5);
            this.Controls.Add(this.btn2);
            this.Controls.Add(this.btnpoint);
            this.Controls.Add(this.btn7);
            this.Controls.Add(this.btn4);
            this.Controls.Add(this.btn1);
            this.Controls.Add(this.txtDisplay);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Click += new System.EventHandler(this.Operational_function);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtDisplay;
        private System.Windows.Forms.Button btn1;
        private System.Windows.Forms.Button btn4;
        private System.Windows.Forms.Button btn7;
        private System.Windows.Forms.Button btnpoint;
        private System.Windows.Forms.Button btn0;
        private System.Windows.Forms.Button btn8;
        private System.Windows.Forms.Button btn5;
        private System.Windows.Forms.Button btn2;
        private System.Windows.Forms.Button btnequal;
        private System.Windows.Forms.Button btn9;
        private System.Windows.Forms.Button btn6;
        private System.Windows.Forms.Button btn3;
        private System.Windows.Forms.Button btntimes;
        private System.Windows.Forms.Button btnminus;
        private System.Windows.Forms.Button btnplus;
        private System.Windows.Forms.Button btnfactional;
        private System.Windows.Forms.Button btnend;
        private System.Windows.Forms.Button btndivide;
        private System.Windows.Forms.Button btnpower;
        private System.Windows.Forms.Button btnpercent;
        private System.Windows.Forms.Button btnclear;
        private System.Windows.Forms.Button btnbackspace;
        private System.Windows.Forms.TextBox textBox1;
    }
}

