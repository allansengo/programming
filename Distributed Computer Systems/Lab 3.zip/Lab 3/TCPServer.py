from socket import socket, AF_INET, SOCK_STREAM

host = "localhost"
port = 2223
buf_size = 1024
addr = (host, port)

TCPSock = socket(AF_INET, SOCK_STREAM)
TCPSock.bind(addr)

TCPSock.listen(10)
client_sock, addr = TCPSock.accept()
print(f"Accepted the connection from {addr}.")

while True:
    bin_data = client_sock.recv(buf_size)
    data = bin_data.decode()
    if data == "\quit":
        print(f"Closing the connection with {addr}.")
        break
    else:
        print(f"Received message '{data}' from {addr}.")

client_sock.close()

