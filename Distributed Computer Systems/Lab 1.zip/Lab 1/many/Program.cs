﻿using System;
using System.Threading;

class Program
{
	static void Fun(int number)
	{
		Console.WriteLine($"Thread number {number} is running...");
	}

	static void Main(string[] args)
	{
		int num_threads = 32;
		Thread[] threads = new Thread[num_threads];
		for (int i = 0; i < num_threads; ++i) {
			int num = i;
			threads[i] = new Thread(() => {
				Fun(num);
			});
			threads[i].Start();
		}
		foreach (var thread in threads) thread.Join();

	}
}

