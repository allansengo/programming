January is the first month and december is the last. Violet is a purple color as are lilac and plum.

// File: SecretFileDemo.java
import java.io.*;
import java.util.*;
public class SecretFileDemo
{
public static void main(String[] args)
{
  try
  {
   Scanner infile = new Scanner(new File("secret.txt"));
   StringBuffer sb = new StringBuffer();
   StringTokenizer tokens;
   
   String line;
   String word;
   char firstChar;
   int count = 0;   
        
   while(infile.hasNextLine())
   {
    line = infile.nextLine();
    
    tokens = new StringTokenizer(line);
    
    while(tokens.hasMoreTokens())
    {
     word = tokens.nextToken();
     count++;
     
     if(count % 5 == 0)
     {
      firstChar = Character.toUpperCase(word.charAt(0));
      
      sb.append(firstChar);
     }
      
    }
   }
   
   System.out.println("Secre word: " + sb);
  }
  catch(FileNotFoundException e)
  {
   System.out.println("Input file is not opened.");
   System.exit(0);
  }
}
}