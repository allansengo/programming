#include <iostream>
#include <thread>
#include <string>


void fun() {
	for (int i = 0; i < 16; ++i) std::cout << "Worker thread: " + std::to_string(i) + "\n";
}


int main() {
	std::thread t{fun};
	for (int i = 0; i < 16; ++i) std::cout << "Main thread: " + std::to_string(i) + "\n";
	t.join();
	return 0;
}

