﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace ITPoland_Project_4
{
    public partial class Form1 : Form
    {
        Bitmap image;
        public Form1()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void showContactsButton_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
            int numberOfContacts = Contacts.contacts.Count();

            if (numberOfContacts < 1)
            {
                MessageBox.Show("Contacts list is empty!");
            }
            else if(numberOfContacts > 1)
            {
                this.Hide();
                form2.numberOfContactsLabel.Text = Contacts.contacts.Count() + "";
                form2.currentContactLabel.Text = 1 + "";
                form2.nameLabel.Text = Contacts.contacts[0].name;
                form2.middleNameLabel.Text = Contacts.contacts[0].middleName;
                form2.lastNameLabel.Text = Contacts.contacts[0].lastName;
                form2.phoneNumberLabel.Text = Contacts.contacts[0].phoneNumber + "";
                form2.addressLabel.Text = Contacts.contacts[0].address;
                form2.genderLabel.Text = Contacts.contacts[0].gender;
                form2.previouseRecordButton.Enabled = false;
                form2.numberOfContacts = numberOfContacts;
                image = new Bitmap(Contacts.contacts[0].pathImage);
                form2.pictureBox1.Image = image;
                form2.ShowDialog();
            }
            else if(numberOfContacts == 1)
            {
                this.Hide();
                form2.numberOfContactsLabel.Text = Contacts.contacts.Count() + "";
                form2.currentContactLabel.Text = 1 + "";
                form2.nameLabel.Text = Contacts.contacts[0].name;
                form2.middleNameLabel.Text = Contacts.contacts[0].middleName;
                form2.lastNameLabel.Text = Contacts.contacts[0].lastName;
                form2.phoneNumberLabel.Text = Contacts.contacts[0].phoneNumber + "";
                form2.addressLabel.Text = Contacts.contacts[0].address;
                form2.genderLabel.Text = Contacts.contacts[0].gender;
                form2.previouseRecordButton.Enabled = false;
                form2.nextRecordButton.Enabled = false;
                form2.numberOfContacts = numberOfContacts;
                image = new Bitmap(Contacts.contacts[0].pathImage);
                form2.pictureBox1.Image = image;
                form2.ShowDialog();
            }
        }

        private void addContactsButton_Click(object sender, EventArgs e)
        {
            Form3 form3 = new Form3();
            this.Hide();
            form3.ShowDialog();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }
    }
}
