﻿
namespace GoTogether_HuntingGame
{
    partial class GameMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.EasyDiffTimeSpeedBtn = new System.Windows.Forms.RadioButton();
            this.MediumDiffTimeSpeedBtn = new System.Windows.Forms.RadioButton();
            this.HardDiffTimeSpeedBtn = new System.Windows.Forms.RadioButton();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.TimeLabel = new System.Windows.Forms.Label();
            this.Scorelabel = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.GameTimer = new System.Windows.Forms.Timer(this.components);
            this.ExitGameMenuBtn = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(14, 60);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(128, 14);
            this.label1.TabIndex = 0;
            this.label1.Text = "( Name Inserted Here)";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(13, 36);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(104, 24);
            this.label2.TabIndex = 1;
            this.label2.Text = "Welcome";
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(17, 108);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 2;
            this.button1.Text = "Start";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(6, 15);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(63, 16);
            this.label3.TabIndex = 3;
            this.label3.Text = "Difficulty";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold);
            this.label4.Location = new System.Drawing.Point(12, 180);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(0, 16);
            this.label4.TabIndex = 4;
            // 
            // EasyDiffTimeSpeedBtn
            // 
            this.EasyDiffTimeSpeedBtn.AutoSize = true;
            this.EasyDiffTimeSpeedBtn.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EasyDiffTimeSpeedBtn.ForeColor = System.Drawing.Color.White;
            this.EasyDiffTimeSpeedBtn.Location = new System.Drawing.Point(7, 39);
            this.EasyDiffTimeSpeedBtn.Name = "EasyDiffTimeSpeedBtn";
            this.EasyDiffTimeSpeedBtn.Size = new System.Drawing.Size(55, 20);
            this.EasyDiffTimeSpeedBtn.TabIndex = 7;
            this.EasyDiffTimeSpeedBtn.TabStop = true;
            this.EasyDiffTimeSpeedBtn.Text = "Easy";
            this.EasyDiffTimeSpeedBtn.UseVisualStyleBackColor = true;
            this.EasyDiffTimeSpeedBtn.CheckedChanged += new System.EventHandler(this.EasyDiffTimeSpeedBtn_CheckedChanged);
            // 
            // MediumDiffTimeSpeedBtn
            // 
            this.MediumDiffTimeSpeedBtn.AutoSize = true;
            this.MediumDiffTimeSpeedBtn.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MediumDiffTimeSpeedBtn.ForeColor = System.Drawing.Color.White;
            this.MediumDiffTimeSpeedBtn.Location = new System.Drawing.Point(6, 65);
            this.MediumDiffTimeSpeedBtn.Name = "MediumDiffTimeSpeedBtn";
            this.MediumDiffTimeSpeedBtn.Size = new System.Drawing.Size(77, 20);
            this.MediumDiffTimeSpeedBtn.TabIndex = 8;
            this.MediumDiffTimeSpeedBtn.TabStop = true;
            this.MediumDiffTimeSpeedBtn.Text = "Medium";
            this.MediumDiffTimeSpeedBtn.UseVisualStyleBackColor = true;
            this.MediumDiffTimeSpeedBtn.CheckedChanged += new System.EventHandler(this.MediumDiffTimeSpeedBtn_CheckedChanged);
            // 
            // HardDiffTimeSpeedBtn
            // 
            this.HardDiffTimeSpeedBtn.AutoSize = true;
            this.HardDiffTimeSpeedBtn.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.HardDiffTimeSpeedBtn.ForeColor = System.Drawing.Color.White;
            this.HardDiffTimeSpeedBtn.Location = new System.Drawing.Point(6, 91);
            this.HardDiffTimeSpeedBtn.Name = "HardDiffTimeSpeedBtn";
            this.HardDiffTimeSpeedBtn.Size = new System.Drawing.Size(56, 20);
            this.HardDiffTimeSpeedBtn.TabIndex = 9;
            this.HardDiffTimeSpeedBtn.TabStop = true;
            this.HardDiffTimeSpeedBtn.Text = "Hard";
            this.HardDiffTimeSpeedBtn.UseVisualStyleBackColor = true;
            this.HardDiffTimeSpeedBtn.CheckedChanged += new System.EventHandler(this.HardDiffTimeSpeedBtn_CheckedChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(1, 12);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(56, 22);
            this.label5.TabIndex = 10;
            this.label5.Text = "Time";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(2, 99);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(65, 22);
            this.label6.TabIndex = 11;
            this.label6.Text = "Score";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.DarkSlateGray;
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Location = new System.Drawing.Point(1, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(192, 524);
            this.panel1.TabIndex = 12;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.label3);
            this.panel3.Controls.Add(this.HardDiffTimeSpeedBtn);
            this.panel3.Controls.Add(this.MediumDiffTimeSpeedBtn);
            this.panel3.Controls.Add(this.EasyDiffTimeSpeedBtn);
            this.panel3.Location = new System.Drawing.Point(16, 157);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(125, 141);
            this.panel3.TabIndex = 13;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.ExitGameMenuBtn);
            this.panel2.Controls.Add(this.TimeLabel);
            this.panel2.Controls.Add(this.Scorelabel);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Location = new System.Drawing.Point(16, 329);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(126, 179);
            this.panel2.TabIndex = 12;
            // 
            // TimeLabel
            // 
            this.TimeLabel.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TimeLabel.ForeColor = System.Drawing.Color.White;
            this.TimeLabel.Location = new System.Drawing.Point(63, 15);
            this.TimeLabel.Name = "TimeLabel";
            this.TimeLabel.Size = new System.Drawing.Size(50, 19);
            this.TimeLabel.TabIndex = 13;
            // 
            // Scorelabel
            // 
            this.Scorelabel.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Scorelabel.ForeColor = System.Drawing.Color.White;
            this.Scorelabel.Location = new System.Drawing.Point(67, 102);
            this.Scorelabel.Name = "Scorelabel";
            this.Scorelabel.Size = new System.Drawing.Size(34, 19);
            this.Scorelabel.TabIndex = 12;
            this.Scorelabel.Text = "0";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox1.Image = global::GoTogether_HuntingGame.Properties.Resources.Smile_face;
            this.pictureBox1.Location = new System.Drawing.Point(453, 172);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(93, 92);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 13;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Visible = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // GameTimer
            // 
            this.GameTimer.Interval = 1000;
            this.GameTimer.Tick += new System.EventHandler(this.GameTimer_Tick);
            // 
            // ExitGameMenuBtn
            // 
            this.ExitGameMenuBtn.BackColor = System.Drawing.Color.Red;
            this.ExitGameMenuBtn.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ExitGameMenuBtn.ForeColor = System.Drawing.Color.White;
            this.ExitGameMenuBtn.Location = new System.Drawing.Point(7, 150);
            this.ExitGameMenuBtn.Name = "ExitGameMenuBtn";
            this.ExitGameMenuBtn.Size = new System.Drawing.Size(75, 23);
            this.ExitGameMenuBtn.TabIndex = 14;
            this.ExitGameMenuBtn.Text = "Exit Game";
            this.ExitGameMenuBtn.UseVisualStyleBackColor = false;
            this.ExitGameMenuBtn.Click += new System.EventHandler(this.ExitGameMenuBtn_Click);
            // 
            // GameMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(787, 519);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label4);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "GameMenu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "GameMenu";
            this.Load += new System.EventHandler(this.GameMenu_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.RadioButton EasyDiffTimeSpeedBtn;
        private System.Windows.Forms.RadioButton MediumDiffTimeSpeedBtn;
        private System.Windows.Forms.RadioButton HardDiffTimeSpeedBtn;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label TimeLabel;
        private System.Windows.Forms.Label Scorelabel;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Timer GameTimer;
        private System.Windows.Forms.Button ExitGameMenuBtn;
    }
}