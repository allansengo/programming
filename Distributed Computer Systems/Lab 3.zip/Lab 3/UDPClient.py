from socket import socket, AF_INET, SOCK_DGRAM

# Set the socket parameters
host = "localhost"
port = 2223
addr = (host, port)

# Create socket
UDPSock = socket(AF_INET, SOCK_DGRAM)

# Send messages
while True:
    data = input(">> ")
    if not data:
        break
    else:
        bin_data = data.encode()
        if(UDPSock.sendto(bin_data, addr)):
            print(f"Sending message '{data}' to {addr}.")

UDPSock.close()

