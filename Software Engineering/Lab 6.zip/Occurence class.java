import java.util. * ;
//Occurence class
class Episode {
int number;
String title, storySynopsis;
Episode(int number,String title, String storySynopsis){
this.number=number;
this.title=title;
this.storySynopsis=storySynopsis;
}
}
//Abstraction class
class TVSeries {
private final List <Episode> episodes;
String seriesName, producer;
TVSeries(String seriesName,String producer,List <Episode> episodes) {
this.episodes = episodes;
this.seriesName=seriesName;
this.producer=producer;
}
public List <Episode> getTotalEpisodesInSeries() {
return episodes;
}
}
public class Demo {
public static void main(String[] args) {
Episode e1 = new Episode(1,"title1","Stroy synopsis of episode1");
Episode e2 = new Episode(2,"title2","Stroy synopsis of episode2");
Episode e3 = new Episode(3,"title3","Stroy synopsis of episode3");
List <Episode> data = new ArrayList <Episode> ();
data.add(e1);
data.add(e2);
data.add(e3);
TVSeries tvSeries = new TVSeries("Flash","Rene",data);
List <Episode> episodes = tvSeries.getTotalEpisodesInSeries();
System.out.println("The Episodes details of series name "+tvSeries.seriesName+":");
for (Episode epi: episodes) {
System.out.println("The Episode Number: " +epi.number+"\nTitle: "+epi.title+"\nStory Synopsis: "+epi.storySynopsis);
System.out.println("------------------------------------------------");
}
}
}

