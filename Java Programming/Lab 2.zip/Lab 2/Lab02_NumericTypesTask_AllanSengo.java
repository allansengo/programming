// TASK #2 Add an import statement for the Scanner class

import java.util.Scanner;
// TASK #2(Alternate)
// Add an import statement for the JOptionPane class

/**
   This program demonstrates how numeric types and
   operators behave in Java.
*/

public class NumericTypes
{
   public static void main (String [] args)
   {
      // TASK #1 
      
      // Identifier declarations
      final int NUMBER = 2 ;        // Number of scores
      final int SCORE1 = 100;       // First test score
      final int SCORE2 = 95;        // Second test score
      final int BOILING_IN_F = 212; // Boiling temperature
      double fToC;                     // Temperature Celsius
      double average;               // Arithmetic average
      String output;                // Line of output

      // Find an arithmetic average.
      average = ( SCORE1 + SCORE2 ) / (double) NUMBER;
      output = SCORE1 + " and " + SCORE2 +
               " have an average of " + average;
      System.out.println(output);

      // Convert Fahrenheit temperature to Celsius.
      fToC = 5./9. * (BOILING_IN_F - 32);
      output = BOILING_IN_F + " in Fahrenheit is " +
               fToC + " in Celsius.";
      System.out.println(output);
   
      System.out.println();      // To leave a blank line


      // ADD LINES FOR TASK #2 HERE

   {
      
      String firstname,lastName ; // To hold a first name & last name  
   
      // Create a Scanner object to read input.
      Scanner keyboard = new Scanner(System.in);
   
      // Get the user's first name
      System.out.print("What is First your name? "); // Prompt the user for first name
      firstname = keyboard.nextLine(); // Read the user's first name

      // Get the user's last name
      System.out.print("What is Last your name? "); // Prompt the user for last name
      lastName = keyboard.nextLine(); // Read the user's last name
   
     // Concatenate the user's first and last names
     System.out.println("Hello, " + firstname + " " + lastName);

     System.out.println();      // To leave a blank line

     
   }
      
   

      // ADD LINES FOR TASK #3 HERE
      {
	    
         String firstName = "";
         String lastName = "";
         Scanner sc = new Scanner(System.in);
      
         System.out.printf("Enter your first name");
          firstName = sc.nextLine();
          
          System.out.printf("Enter your last name");
          lastName = sc.nextLine();
          
          String fullName = firstName + " " + lastName;
          
          // Get the first character from the user's first name
         char firstInitial = firstName.charAt(0);
         // Print out the user's first initial
         System.out.println("First Name Initial" + firstInitial);

         // Convert the user's full name to uppercase
         fullName = fullName.toUpperCase();
         System.out.println("Full Name" + fullName);

          // Print out the user's full name in uppercase
         System.out.println("Number of Characters in Full Name" + fullName.length());
         char firstInitialUp = Character.toUpperCase(firstInitial);
         System.out.println("First Name Initial in Upper Case" + firstInitialUp);

         System.out.println();      // To leave a blank line
     }
      
      System.out.println();      // To leave a blank line

      // ADD LINES FOR TASK #4 HERE
      {
         System.out.println("This program calculates the volume of a sphere."); // Prompt the user for a diameter of a sphere
         System.out.printf("Enter the diameter of the sphere: "); // Read the diameter
         Scanner sc = new Scanner(System.in);
          
         
          double diameter = sc.nextDouble(); 
          double radius = diameter/2; // Calculate the radius
          
          double volume = (4 * (Math.PI) * (Math.pow(radius,3)))/3; // Calculate the volume
          
          System.out.println("\nDiameter:\t" + diameter); 
          System.out.println("Radius:\t\t" + radius); 
          System.out.printf("Volume:\t\t%.2f\n", volume); // Print out the volume
     }
     
   }
}