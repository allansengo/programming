from threading import Thread


def fun():
    for i in range(16):
        print(f"Worker thread: {i}\n", end="")


def main():
    t = Thread(target=fun)
    t.start()
    for i in range(16):
        print(f"Main thread: {i}\n", end="")
    t.join()


if __name__ == "__main__":
    main()

