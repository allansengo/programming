﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace ITPoland_Project_4
{
    static class Program
    {
        public static List<Contact> phones = new List<Contact>();
        
        /// <summary>
        /// </summary>
        [STAThread]
        static void Main()
        {
            FileStream fs = new FileStream("contacts.txt", FileMode.Open, FileAccess.Read);
            StreamReader sr = new StreamReader(fs);

            string name;
            string middleName;
            string lastName;
            long phoneNumber;
            string address;
            string gender;
            string pathImage;

            while (!sr.EndOfStream)
            {
                sr.ReadLine();
                name = sr.ReadLine();
                middleName = sr.ReadLine();
                lastName = sr.ReadLine();
                phoneNumber = Convert.ToInt64(sr.ReadLine());
                address = sr.ReadLine();
                gender = sr.ReadLine();
                pathImage = sr.ReadLine();
                if (name != null && lastName != null && address != null && gender != null && pathImage != null)
                {
                    Contacts.contacts.Add(new Contact(name, middleName, lastName, phoneNumber, address, gender, pathImage));
                }
            }
            
            sr.Close();
            fs.Close();
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
}
